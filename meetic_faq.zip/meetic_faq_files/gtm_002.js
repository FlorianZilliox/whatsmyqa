
// Copyright 2012 Google Inc. All rights reserved.
(function(w,g){w[g]=w[g]||{};w[g].e=function(s){return eval(s);};})(window,'google_tag_manager');(function(){

var data = {
"resource": {
  "version":"121",
  
  "macros":[{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.reg_form_gender"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.reg_form_gender_search"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",0],8,16],",b=",["escape",["macro",1],8,16],";if(a\u0026\u0026b)return[\"M\",\"F\"].includes(a)?[\"M\",\"F\"].includes(b)?a+b:(console.warn(\"[GTM] mg.reg_form_kvk: invalid reg_form_gender_search given\"),\"invalid\"):(console.warn(\"[GTM] mg.reg_form_kvk: invalid reg_form_gender given\"),\"invalid\")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.reg_form_age"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",3],8,16],";if(a){a=parseInt(a,10);if(!Number.isInteger(a))return console.warn(\"[GTM] mg.reg_form_age.range: non-integer value passed\"),\"invalid\";var d=[{value:\"18-24\",min:18,max:24},{value:\"25-27\",min:25,max:27},{value:\"28-29\",min:28,max:29},{value:\"30-34\",min:30,max:34},{value:\"35-39\",min:35,max:39},{value:\"40-44\",min:40,max:44},{value:\"45-49\",min:45,max:49},{value:\"50-54\",min:50,max:54},{value:\"55-59\",min:55,max:59},{value:\"60-64\",min:60,max:64},{value:\"65-69\",min:65,\nmax:69},{value:\"70+\",min:70}],c=!1;d.some(function(b){if(a\u003E=b.min\u0026\u0026(!b.max||a\u003C=b.max))return c=b.value,!0});return c?c:(console.warn(\"[GTM] mg.reg_form_age.range: unable to resolve mg.reg_form_age to an age bracket\"),\"invalid\")}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.SEO_age"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",5],8,16],";if(a){a=parseInt(a,10);if(!Number.isInteger(a))return console.warn(\"[GTM] mg.SEO_age.range: non-integer value passed\"),\"invalid\";var d=[{value:\"18-24\",min:18,max:24},{value:\"25-27\",min:25,max:27},{value:\"28-29\",min:28,max:29},{value:\"30-34\",min:30,max:34},{value:\"35-39\",min:35,max:39},{value:\"40-44\",min:40,max:44},{value:\"45-49\",min:45,max:49},{value:\"50-54\",min:50,max:54},{value:\"55-59\",min:55,max:59},{value:\"60-64\",min:60,max:64},{value:\"65-69\",min:65,max:69},\n{value:\"70+\",min:70}],c=!1;d.some(function(b){if(a\u003E=b.min\u0026\u0026(!b.max||a\u003C=b.max))return c=b.value,!0});return c?c:(console.warn(\"[GTM] mg.SEO_age.range: unable to resolve mg.SEO_age to an age bracket\"),\"invalid\")}})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.one_trust.active_groups"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"cookie_ads"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",7],8,16],";if(null!==a\u0026\u0026\"object\"===typeof a\u0026\u0026a.ads)return a.ads;a=",["escape",["macro",8],8,16],";return void 0===a||null===a?\"pending\":[\"yes\",\"no\"].includes(a)?a:(console.warn(\"[GTM] cookie_policy.ad_features: Unsuported value found for cookie_policy.ad_features.cookie\"),\"invalid\")})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"cookie_socials"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",7],8,16],";if(null!==a\u0026\u0026\"object\"===typeof a\u0026\u0026a.socials)return a.socials;a=",["escape",["macro",10],8,16],";return void 0===a||null===a?\"pending\":[\"yes\",\"no\"].includes(a)?a:(console.warn(\"[GTM] cookie_policy.socials: Unsuported value found for cookie_policy.socials.cookie\"),\"invalid\")})();"]
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"cookie_analytics"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",7],8,16],";if(null!==a\u0026\u0026\"object\"===typeof a\u0026\u0026a.analytics)return a.analytics;a=",["escape",["macro",12],8,16],";return void 0===a||null===a?\"pending\":[\"yes\",\"no\"].includes(a)?a:(console.warn(\"[GTM] cookie_policy.analytics: Unsuported value found for cookie_policy.analytics.cookie\"),\"invalid\")})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_relation_type"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",14],8,16],"?\",\"+",["escape",["macro",14],8,16],"+\",\":void 0})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_studies"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",16],8,16],"?\",\"+",["escape",["macro",16],8,16],"+\",\":void 0})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_hair_color"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",18],8,16],"?\",\"+",["escape",["macro",18],8,16],"+\",\":void 0})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_ethnicity"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return undefined;return ",["escape",["macro",20],8,16],"?\",\"+",["escape",["macro",20],8,16],"+\",\":undefined})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_religion"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return undefined;return ",["escape",["macro",22],8,16],"?\",\"+",["escape",["macro",22],8,16],"+\",\":undefined})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.search_hobbies"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return ",["escape",["macro",24],8,16],"?\",\"+",["escape",["macro",24],8,16],"+\",\":void 0})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.site_language"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",26],8,16],";if(a)return a=a.match(\/^[a-z]{2}\/g),a\u0026\u0026a.length?a.pop():(console.warn(\"[GTM] mg.site_language.ga: Unable to extract language from mg.site_language\"),\"invalid\")})();"]
    },{
      "function":"__j",
      "vtp_name":"window.mg_gtm_WPNZTTN.storage"
    },{
      "function":"__c",
      "vtp_value":"has_logged_once"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",28],8,16],";a=a.get(",["escape",["macro",29],8,16],",a.POLICIES.analytics);return\"yes\"===a?\"yes\":\"no\"})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.age"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",31],8,16],";if(a){a=parseInt(a,10);if(!Number.isInteger(a))return console.warn(\"[GTM] mg.age.range: non-integer value passed\"),\"invalid\";var d=[{value:\"18-24\",min:18,max:24},{value:\"25-27\",min:25,max:27},{value:\"28-29\",min:28,max:29},{value:\"30-34\",min:30,max:34},{value:\"35-39\",min:35,max:39},{value:\"40-44\",min:40,max:44},{value:\"45-49\",min:45,max:49},{value:\"50-54\",min:50,max:54},{value:\"55-59\",min:55,max:59},{value:\"60-64\",min:60,max:64},{value:\"65-69\",min:65,max:69},\n{value:\"70+\",min:70}],c=!1;d.some(function(b){if(a\u003E=b.min\u0026\u0026(!b.max||a\u003C=b.max))return c=b.value,!0});return c?c:(console.warn(\"[GTM] mg.age.range: unable to resolve mg.age to an age bracket\"),\"invalid\")}})();"]
    },{
      "function":"__c",
      "vtp_value":"reg_success"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",28],8,16],";a=",["escape",["macro",28],8,16],".get(",["escape",["macro",33],8,16],",a.POLICIES.analytics);return\"yes\"===a?\"yes\":\"no\"})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.code_market"
    },{
      "function":"__k",
      "vtp_decodeCookie":false,
      "vtp_name":"meetic_cmk"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",35],8,16],";if(null!==a\u0026\u0026void 0!==a)return a;a=",["escape",["macro",36],8,16],";return null!==a\u0026\u0026void 0!==a?a:\"none\"})();"]
    },{
      "function":"__c",
      "vtp_value":"ga_126752871_client_id"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",28],8,16],",c=",["escape",["macro",38],8,16],",b=a.get(c,a.POLICIES.analytics);if(b)return b;b=\"MG.\"+Math.floor(1E9*Math.random()).toString().padStart(9,\"0\")+\".\"+Math.floor(Date.now()\/1E3);a.set(c,b,a.DURATIONS.year,a.POLICIES.analytics);return b})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return location.host.split(\".\").splice(\".\").slice(-2).join(\".\")})();"]
    },{
      "function":"__c",
      "vtp_value":"last_order_id"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=",["escape",["macro",28],8,16],";return a.get(",["escape",["macro",41],8,16],",a.POLICIES.analytics)})();"]
    },{
      "function":"__e"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.abo_id"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){var a=\"yes\"===",["escape",["macro",30],8,16],"?void 0:\"none\";if(\"yes\"!==",["escape",["macro",13],8,16],")return a;var b=",["escape",["macro",44],8,16],";return b?b:a})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"none\"===",["escape",["macro",45],8,16],"?void 0:",["escape",["macro",45],8,16],"})();"]
    },{
      "function":"__v",
      "convert_null_to":"none",
      "convert_undefined_to":"none",
      "convert_false_to":"none",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"none",
      "vtp_name":"mg.page_name"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"yes\"===",["escape",["macro",9],8,16],"})();"]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"yes\"===",["escape",["macro",13],8,16],"?void 0:\"none\"})();"]
    },{
      "function":"__c",
      "vtp_value":"1"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.page_category"
    },{
      "function":"__c",
      "vtp_value":"2"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.brand_name"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",53],
      "vtp_defaultValue":["macro",53],
      "vtp_map":["list",["map","key","disonsdemain","value","ourtime"],["map","key","zweisam","value","ourtime"],["map","key","lovescout24","value","friendscout24"]]
    },{
      "function":"__c",
      "vtp_value":"3"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.site_version"
    },{
      "function":"__c",
      "vtp_value":"4"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.site_country"
    },{
      "function":"__c",
      "vtp_value":"42"
    },{
      "function":"__c",
      "vtp_value":"43"
    },{
      "function":"__c",
      "vtp_value":"44"
    },{
      "function":"__c",
      "vtp_value":"45"
    },{
      "function":"__c",
      "vtp_value":"46"
    },{
      "function":"__v",
      "convert_null_to":"dev",
      "convert_undefined_to":"dev",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"dev",
      "vtp_name":"mg.env"
    },{
      "function":"__c",
      "vtp_value":"47"
    },{
      "function":"__cid"
    },{
      "function":"__ctv"
    },{
      "function":"__c",
      "vtp_value":["template",["macro",66],"-",["macro",67]]
    },{
      "function":"__c",
      "vtp_value":"48"
    },{
      "function":"__c",
      "vtp_value":"51"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"yes\"===",["escape",["macro",9],8,16],"?\"yes\":\"no\"})();"]
    },{
      "function":"__c",
      "vtp_value":"52"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.ab_test_id"
    },{
      "function":"__smm",
      "convert_null_to":"none",
      "convert_undefined_to":"none",
      "convert_false_to":"none",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",73],
      "vtp_defaultValue":["macro",73],
      "vtp_map":["list",["map","key","0","value","none"]]
    },{
      "function":"__c",
      "vtp_value":"53"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.landing_id"
    },{
      "function":"__c",
      "vtp_value":"54"
    },{
      "function":"__c",
      "vtp_value":"55"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.description"
    },{
      "function":"__c",
      "vtp_value":"57"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":true,
      "vtp_defaultValue":"pending",
      "vtp_name":"gtm.has_ad_blocker"
    },{
      "function":"__c",
      "vtp_value":"58"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.page_sub_category"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",58],
      "vtp_defaultValue":"no",
      "vtp_map":["list",["map","key","PT","value","yes"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",64],
      "vtp_defaultValue":"yes",
      "vtp_map":["list",["map","key","local","value","yes"],["map","key","dev","value","yes"],["map","key","test","value","yes"],["map","key","recette","value","yes"],["map","key","kuberecette","value","yes"],["map","key","preprod","value","yes"],["map","key","prod","value","no"]]
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){return\"yes\"===",["escape",["macro",84],8,16],"||\"yes\"===",["escape",["macro",85],8,16],"?\"yes\":\"no\"})();"]
    },{
      "function":"__c",
      "vtp_value":"UA-126752871-1"
    },{
      "function":"__c",
      "vtp_value":"UA-126752871-2"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",86],
      "vtp_defaultValue":["macro",87],
      "vtp_map":["list",["map","key","yes","value",["macro",87]],["map","key","no","value",["macro",88]]]
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":true,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","userId","value",["macro",46]],["map","fieldName","language","value",["macro",27]],["map","fieldName","page","value",["macro",47]],["map","fieldName","anonymizeIp","value","true"],["map","fieldName","allowAdFeatures","value",["macro",48]],["map","fieldName","storage","value",["macro",49]],["map","fieldName","clientId","value",["macro",39]]],
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index",["macro",50],"dimension",["macro",51]],["map","index",["macro",52],"dimension",["macro",54]],["map","index",["macro",55],"dimension",["macro",56]],["map","index",["macro",57],"dimension",["macro",58]],["map","index",["macro",59],"dimension",["macro",45]],["map","index",["macro",60],"dimension",["macro",9]],["map","index",["macro",61],"dimension",["macro",13]],["map","index",["macro",62],"dimension",["macro",11]],["map","index",["macro",63],"dimension",["macro",64]],["map","index",["macro",65],"dimension",["macro",68]],["map","index",["macro",69],"dimension",["macro",45]],["map","index",["macro",70],"dimension",["macro",71]],["map","index",["macro",72],"dimension",["macro",74]],["map","index",["macro",75],"dimension",["macro",76]],["map","index",["macro",77],"dimension",["macro",37]],["map","index",["macro",78],"dimension",["macro",79]],["map","index",["macro",80],"dimension",["macro",81]],["map","index",["macro",82],"dimension",["macro",83]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":["macro",89],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.event_category"
    },{
      "function":"__c",
      "vtp_value":"5"
    },{
      "function":"__c",
      "vtp_value":"6"
    },{
      "function":"__c",
      "vtp_value":"7"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.reg_form_living_city"
    },{
      "function":"__c",
      "vtp_value":"8"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.reg_form_living_country"
    },{
      "function":"__c",
      "vtp_value":"9"
    },{
      "function":"__c",
      "vtp_value":"10"
    },{
      "function":"__c",
      "vtp_value":"11"
    },{
      "function":"__c",
      "vtp_value":"12"
    },{
      "function":"__c",
      "vtp_value":"13"
    },{
      "function":"__c",
      "vtp_value":"14"
    },{
      "function":"__c",
      "vtp_value":"15"
    },{
      "function":"__c",
      "vtp_value":"16"
    },{
      "function":"__c",
      "vtp_value":"17"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.product_category"
    },{
      "function":"__c",
      "vtp_value":"18"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.product_name"
    },{
      "function":"__c",
      "vtp_value":"19"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.SEO_gender"
    },{
      "function":"__c",
      "vtp_value":"20"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.SEO_gender_search"
    },{
      "function":"__c",
      "vtp_value":"21"
    },{
      "function":"__c",
      "vtp_value":"22"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.SEO_living_city"
    },{
      "function":"__c",
      "vtp_value":"28"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.gender"
    },{
      "function":"__c",
      "vtp_value":"29"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.gender_search"
    },{
      "function":"__c",
      "vtp_value":"30"
    },{
      "function":"__c",
      "vtp_value":"31"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.living_city"
    },{
      "function":"__c",
      "vtp_value":"32"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.living_country"
    },{
      "function":"__c",
      "vtp_value":"40"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.has_pass"
    },{
      "function":"__c",
      "vtp_value":"41"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.has_pass_date"
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":true,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","userId","value",["macro",46]],["map","fieldName","language","value",["macro",27]],["map","fieldName","anonymizeIp","value","true"],["map","fieldName","allowAdFeatures","value",["macro",48]],["map","fieldName","page","value",["macro",47]],["map","fieldName","storage","value",["macro",49]],["map","fieldName","clientId","value",["macro",39]]],
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index",["macro",50],"dimension",["macro",51]],["map","index",["macro",52],"dimension",["macro",54]],["map","index",["macro",55],"dimension",["macro",56]],["map","index",["macro",57],"dimension",["macro",58]],["map","index",["macro",92],"dimension",["macro",0]],["map","index",["macro",93],"dimension",["macro",1]],["map","index",["macro",94],"dimension",["macro",95]],["map","index",["macro",96],"dimension",["macro",97]],["map","index",["macro",98],"dimension",["macro",4]],["map","index",["macro",99],"dimension",["macro",2]],["map","index",["macro",100],"dimension",["macro",15]],["map","index",["macro",101],"dimension",["macro",17]],["map","index",["macro",102],"dimension",["macro",19]],["map","index",["macro",103],"dimension",["macro",21]],["map","index",["macro",104],"dimension",["macro",23]],["map","index",["macro",105],"dimension",["macro",25]],["map","index",["macro",106],"dimension",["macro",107]],["map","index",["macro",108],"dimension",["macro",109]],["map","index",["macro",110],"dimension",["macro",111]],["map","index",["macro",112],"dimension",["macro",113]],["map","index",["macro",114],"dimension",["macro",6]],["map","index",["macro",115],"dimension",["macro",116]],["map","index",["macro",59],"dimension",["macro",45]],["map","index",["macro",60],"dimension",["macro",9]],["map","index",["macro",61],"dimension",["macro",13]],["map","index",["macro",62],"dimension",["macro",11]],["map","index",["macro",63],"dimension",["macro",64]],["map","index",["macro",65],"dimension",["macro",68]],["map","index",["macro",117],"dimension",["macro",118]],["map","index",["macro",119],"dimension",["macro",120]],["map","index",["macro",121],"dimension",["macro",32]],["map","index",["macro",122],"dimension",["macro",123]],["map","index",["macro",124],"dimension",["macro",125]],["map","index",["macro",126],"dimension",["macro",127]],["map","index",["macro",128],"dimension",["macro",129]],["map","index",["macro",69],"dimension",["macro",45]],["map","index",["macro",70],"dimension",["macro",71]],["map","index",["macro",77],"dimension",["macro",37]],["map","index",["macro",82],"dimension",["macro",83]],["map","index",["macro",72],"dimension",["macro",74]],["map","index",["macro",75],"dimension",["macro",76]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":["macro",89],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.event_action"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.event_label"
    },{
      "function":"__gas",
      "vtp_cookieDomain":"auto",
      "vtp_doubleClick":false,
      "vtp_setTrackerName":false,
      "vtp_useDebugVersion":false,
      "vtp_fieldsToSet":["list",["map","fieldName","allowAdFeatures","value","false"],["map","fieldName","anonymizeIp","value","true"],["map","fieldName","language","value",["macro",27]],["map","fieldName","page","value",["macro",47]],["map","fieldName","storage","value",["macro",49]],["map","fieldName","userId","value",["macro",46]],["map","fieldName","clientId","value",["macro",39]]],
      "vtp_useHashAutoLink":false,
      "vtp_decorateFormsAutoLink":false,
      "vtp_enableLinkId":false,
      "vtp_dimension":["list",["map","index",["macro",60],"dimension",["macro",9]],["map","index",["macro",61],"dimension",["macro",13]],["map","index",["macro",62],"dimension",["macro",11]],["map","index",["macro",59],"dimension",["macro",45]],["map","index",["macro",63],"dimension",["macro",64]],["map","index",["macro",65],"dimension",["macro",68]],["map","index",["macro",69],"dimension",["macro",45]],["map","index",["macro",72],"dimension",["macro",74]],["map","index",["macro",75],"dimension",["macro",76]]],
      "vtp_enableEcommerce":false,
      "vtp_trackingId":["macro",89],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.payment.pay_pass_id"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.payment.ordercode"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.payment.orderdate"
    },{
      "function":"__jsm",
      "vtp_javascript":["template","(function(){if(!",["escape",["macro",134],8,16],"||0!==",["escape",["macro",134],8,16],".indexOf(\"PASS_\"))return\"no\";var b=",["escape",["macro",135],8,16],";if(!b)return\"no\";var a=parseInt(",["escape",["macro",136],8,16],");isNaN(a)||(a=new Date(1E3*a));if(!(a instanceof Date)||isNaN(a.getTime()))console.warn(\"[GTM] payment.purchase.is_pass_success: invalid date format for `mg.payment.orderdate`\",",["escape",["macro",136],8,16],");else if(1728E5\u003Cnew Date-a)return\"no\";return(a=",["escape",["macro",42],8,16],")\u0026\u0026a==b?\"no\":\"yes\"})();"]
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"mg.payment.pay_life_cycle"
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",138],
      "vtp_defaultValue":"invalid",
      "vtp_map":["list",["map","key","0","value","REG"],["map","key","1","value","FTS"],["map","key","2","value","TERM"],["map","key","3","value","RESUB"],["map","key","4","value","RESUB-STACK"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",118],
      "vtp_defaultValue":"0",
      "vtp_map":["list",["map","key","F","value","2"],["map","key","M","value","1"]]
    },{
      "function":"__smm",
      "vtp_setDefaultValue":true,
      "vtp_input":["macro",32],
      "vtp_defaultValue":"0000",
      "vtp_map":["list",["map","key","18-24","value","0024"],["map","key","25-27","value","2534"],["map","key","28-29","value","2534"],["map","key","30-34","value","2534"],["map","key","35-39","value","3544"],["map","key","40-44","value","3544"],["map","key","45-49","value","4554"],["map","key","50-54","value","4554"],["map","key","55-59","value","5564"],["map","key","60-64","value","5564"],["map","key","65-69","value","6500"],["map","key","70+","value","6500"],["map","key","invalid","value","0000"]]
    },{
      "function":"__c",
      "vtp_value":"4"
    },{
      "function":"__c",
      "vtp_value":"2"
    },{
      "function":"__c",
      "vtp_value":"8"
    },{
      "function":"__c",
      "vtp_value":"23"
    },{
      "function":"__c",
      "vtp_value":"24"
    },{
      "function":"__c",
      "vtp_value":"25"
    },{
      "function":"__c",
      "vtp_value":"26"
    },{
      "function":"__c",
      "vtp_value":"27"
    },{
      "function":"__c",
      "vtp_value":"33"
    },{
      "function":"__c",
      "vtp_value":"34"
    },{
      "function":"__c",
      "vtp_value":"35"
    },{
      "function":"__c",
      "vtp_value":"36"
    },{
      "function":"__c",
      "vtp_value":"37"
    },{
      "function":"__c",
      "vtp_value":"38"
    },{
      "function":"__c",
      "vtp_value":"39"
    },{
      "function":"__v",
      "vtp_dataLayerVersion":2,
      "vtp_setDefaultValue":false,
      "vtp_name":"OnetrustActiveGroups"
    },{
      "function":"__c",
      "vtp_value":"56"
    },{
      "function":"__c",
      "vtp_value":"6LeFqaQUAAAAAM1EN1izwGGETLNy1Yq-ZHQZ-k5s"
    },{
      "function":"__u",
      "vtp_component":"PATH",
      "vtp_enableMultiQueryKeys":false,
      "vtp_enableIgnoreEmptyQueryParam":false
    },{
      "function":"__e"
    }],
  "tags":[{
      "function":"__html",
      "priority":1000,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\n\u003Cscript type=\"text\/gtmscript\"\u003E(function(){if(void 0===window.mg_gtm_WPNZTTN||void 0===window.mg_gtm_WPNZTTN.storage){var f=function(){var f=function(){var c={};return{set:function(e,g){c[e]=g},get:function(e){return c[e]},remove:function(e){delete c[e]}}}(),h=function(){function c(b,a,d){this._setter=b;this._getter=a;this._remover=d}c.prototype._maxAgeKey=function(b){return b+\"_expire\"};c.prototype.set=function(b,a,d){this._setter(this._maxAgeKey(b),d.getTime().toString(),d);this._setter(b,a,d)};c.prototype.get=function(b){var a=\nnew Date(parseInt(this._getter(this._maxAgeKey(b))));if(isNaN(a.getTime())||a.getTime()\u003C=Date.now())return this.remove(b),null;var d=this._getter(b);return d?{value:d,maxAge:a}:(this.remove(b),null)};c.prototype.remove=function(b){this._remover(b);this._remover(this._maxAgeKey(b))};var e=new c(function(b,a,d){try{window.localStorage.setItem(b,a)}catch(m){console.debug(\"gtm.storage: local storage not available\",m)}},function(b){try{return window.localStorage.getItem(b)||null}catch(a){return console.debug(\"gtm.storage: local storage not available\",\na),null}},function(b){try{window.localStorage.removeItem(b)}catch(a){console.debug(\"gtm.storage: local storage not available\",a)}}),g=function(){var b=function(a){a=a.split(\".\").slice(-2);return 1\u003Ca.length?a.join(\".\"):null};return new c(function(a,d,c){d=encodeURIComponent(d);a=a+\"\\x3d\"+d+\";expires\\x3d\"+c.toUTCString()+\";path\\x3d\/;\";document.cookie=a;if(d=b(location.host))document.cookie=a+\"domain\\x3d\"+d+\";\"},function(a){return(a=document.cookie.match(\"(^|[^;]+)\\\\s*\"+a+\"\\\\s*\\x3d\\\\s*([^;]+)\"))?decodeURIComponent(a.pop()):\nnull},function(a){a+=\"\\x3d;expires\\x3dThu, 01 Jan 1970 00:00:00 UTC;path\\x3d\/;\";document.cookie=a;var d=b(location.host);d\u0026\u0026(document.cookie=a+\"domain\\x3d\"+b(location.host)+\";\")})}();return{DURATIONS:{year:31536E6,day:864E5,hour:36E5},set:function(b,a,d){var c=b;var f=d;Number.isInteger(f)?c=!0:(console.warn(\"gtm.storage: ttl should be expressed in seconds\",c,f),c=!1);c\u0026\u0026(d=new Date(d+Date.now()),b=\"mg_gtm_WPNZTTN_\"+b,g.set(b,a,d),e.set(b,a,d))},get:function(b){b=\"mg_gtm_WPNZTTN_\"+b;var a=g.get(b),\nc=e.get(b);return a\u0026\u0026c?a.value:a?(e.set(b,a.value,a.maxAge),a.value):c?(g.set(b,c.value,c.maxAge),c.value):null},remove:function(b){b=\"mg_gtm_WPNZTTN_\"+b;g.remove(b);e.remove(b)}}}(),k=function(){var c={ads:\"ads\",analytics:\"analytics\",socials:\"socials\"},e={ads:\"no\",analytics:\"no\",socials:\"no\"},f=function(b,a,c){return[b,a,c].map(function(d){return[\"yes\",\"no\",\"pending\"].includes(d)?!0:(console.warn(\"gtm.storage: invalid privacy settings\",{ads:b,analytics:a,socials:c}),!1)}).includes(!1)};return{POLICIES:c,\nisPersistentStorageEnabled:function(b){var a=b;Object.values(c).includes(a)?a=!0:(console.warn(\"gtm.storage: invalid privacy setting name\",a),a=!1);return a?\"yes\"===e[b]:!1},update:function(b,a,c){f(b,a,c);e={ads:b,analytics:a,socials:c}}}}(),l=function(c){return\"string\"===typeof c\u0026\u0026\/^\\w+$\/.test(c)?!0:(console.warn(\"gtm.storage: can only store ^w+$ keys\",c),!1)};return{DURATIONS:h.DURATIONS,POLICIES:k.POLICIES,updatePrivacySettings:k.update,set:function(c,e,g,b){var a;(a=!l(c))||(\"string\"!==typeof e||\n\"\"===e?(console.warn(\"gtm.storage: can only store non empty string values\",c,e),a=!1):a=!0,a=!a);a||(f.set(c,e),k.isPersistentStorageEnabled(b)\u0026\u0026h.set(c,e,g))},get:function(c,e){if(!l(c))return null;var g=f.get(c);if(void 0!==g)return g;if(!k.isPersistentStorageEnabled(e))return null;g=h.get(c)||null;f.set(c,g);return g},remove:function(c){f.remove(c);h.remove(c)}}}();f.updatePrivacySettings(",["escape",["macro",9],8,16],",",["escape",["macro",13],8,16],",",["escape",["macro",11],8,16],");var h=document.cookie.match(\"(^|[^;]+)\\\\s*ga_126752871_client_id\\\\s*\\x3d\\\\s*([^;]+)\");\nh\u0026\u0026!document.cookie.match(\"(^|[^;]+)\\\\s*ga_126752871_client_id_expire\\\\s*\\x3d\\\\s*([^;]+)\")\u0026\u0026f.set(\"ga_126752871_client_id\",h.pop(),f.DURATIONS.year,f.POLICIES.analytics);if(h=document.cookie.match(\"(^|[^;]+)\\\\s*mg_gtm_has_logged_once\\\\s*\\x3d\\\\s*([^;]+)\"))f.set(\"has_logged_once\",h.pop(),f.DURATIONS.year,f.POLICIES.analytics),document.cookie=\"mg_gtm_has_logged_once\\x3d;expires\\x3dThu, 01 Jan 1970 00:00:00 UTC;path\\x3d\/;\";void 0===window.mg_gtm_WPNZTTN\u0026\u0026(window.mg_gtm_WPNZTTN={});window.mg_gtm_WPNZTTN.storage=\nf}})();\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":47
    },{
      "function":"__html",
      "priority":500,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003Eif(void 0!==OptanonWrapper)throw Error(\"[GTM] OptanonWrapper already defined, aborting\");\nvar OptanonWrapper=function(){var b=!0;return function(){if(b)console.debug(\"[GTM] Cookie consent update received through `OptanonWrapper` handler. Event ignored: sent during OneTrust SDK boot.\"),b=!1;else if(void 0===dataLayer)console.warn(\"[GTM] Receiving cookie consent update through `OptanonWrapper` handler when the datalayer is not yet initialised\");else{var a=window.google_tag_manager[",["escape",["macro",66],8,16],"].dataLayer.get(\"OnetrustActiveGroups\");\"string\"!==typeof a?console.warn(\"[GTM] Receiving cookie consent update through `OptanonWrapper` handler but `OnetrustActiveGroups` does not contain new active groups.\",\na):(a=a.split(\",\"),a={ads:-1!==a.indexOf(",["escape",["macro",142],8,16],")?\"yes\":\"no\",analytics:-1!==a.indexOf(",["escape",["macro",143],8,16],")?\"yes\":\"no\",socials:-1!==a.indexOf(",["escape",["macro",144],8,16],")?\"yes\":\"no\"},",["escape",["macro",28],8,16],".updatePrivacySettings(a.ads,a.analytics,a.socials),dataLayer.push({event:\"mg.event\",\"mg.event_category\":\"CookieConsent\",\"mg.event_action\":\"Update\",\"mg.event_label\":\"CookieConsentUpdate\",\"mg.one_trust.active_groups\":a}),console.debug(\"[GTM] Cookie consent update received through `OptanonWrapper` handler. Event forwarded to datalayer\"))}}}();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":14
    },{
      "function":"__html",
      "priority":500,
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=",["escape",["macro",28],8,16],";a.set(",["escape",["macro",38],8,16],",",["escape",["macro",39],8,16],",a.DURATIONS.year,a.POLICIES.analytics)})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":48
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_overrideGaSettings":false,
      "vtp_trackType":"TRACK_PAGEVIEW",
      "vtp_gaSettings":["macro",90],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "tag_id":1
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":["macro",91],
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",130],
      "vtp_eventAction":["macro",131],
      "vtp_eventLabel":["macro",132],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":3
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"CookieConsent",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",133],
      "vtp_eventAction":"Update",
      "vtp_eventLabel":"CookieConsentUpdate",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":15
    },{
      "function":"__ua",
      "metadata":["map"],
      "teardown_tags":["list",["tag",17,0]],
      "once_per_load":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":true,
      "vtp_eventValue":["macro",135],
      "vtp_fieldsToSet":["list",["map","fieldName","page","value","\/payment-success"]],
      "vtp_eventCategory":"Payment",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",130],
      "vtp_eventAction":"Subscription",
      "vtp_eventLabel":["macro",139],
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":18
    },{
      "function":"__ua",
      "metadata":["map"],
      "teardown_tags":["list",["tag",11,0]],
      "once_per_load":true,
      "vtp_nonInteraction":false,
      "vtp_overrideGaSettings":false,
      "vtp_eventValue":["template",["macro",140],["macro",141]],
      "vtp_eventCategory":"Reg",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",130],
      "vtp_eventAction":"Success",
      "vtp_eventLabel":"RegSuccess",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":23
    },{
      "function":"__ua",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_nonInteraction":true,
      "vtp_overrideGaSettings":false,
      "vtp_eventCategory":"Acquisition",
      "vtp_trackType":"TRACK_EVENT",
      "vtp_gaSettings":["macro",130],
      "vtp_eventAction":"RegFormVisit",
      "vtp_eventLabel":"AcquisitionRegFormVisit",
      "vtp_enableRecaptchaOption":false,
      "vtp_enableUaRlsa":false,
      "vtp_enableUseInternalVersion":false,
      "vtp_enableFirebaseCampaignData":true,
      "vtp_trackTypeIsEvent":true,
      "tag_id":32
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){if(",["escape",["macro",44],8,16],"){var a=",["escape",["macro",28],8,16],";a.set(",["escape",["macro",29],8,16],",\"yes\",a.DURATIONS.year,a.POLICIES.analytics)}})();\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":16
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=",["escape",["macro",28],8,16],";a.set(",["escape",["macro",33],8,16],",\"yes\",a.DURATIONS.hour,a.POLICIES.analytics)})();\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":21
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E",["escape",["macro",28],8,16],".remove(",["escape",["macro",33],8,16],");\u003C\/script\u003E\n\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":22
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){var a=document.createElement(\"ins\");a.className=\"AdSense\";a.style.display=\"block\";a.style.position=\"absolute\";a.style.top=\"-1px\";a.style.height=\"1px\";document.body.appendChild(a);window.google_tag_manager[",["escape",["macro",66],8,16],"].dataLayer.set(\"gtm.has_ad_blocker\",0===a.clientHeight?\"yes\":\"no\");document.body.removeChild(a)})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":46
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){",["escape",["macro",28],8,16],".remove(",["escape",["macro",38],8,16],");var a=location.host.split(\".\").slice(-2);a=2\u003C=a.length?a.join(\".\"):location.host;[\"_ga\"].map(function(b){document.cookie=b+\"\\x3d; Path\\x3d\/; Expires\\x3dThu, 01 Jan 1970 00:00:01 GMT;\";document.cookie=b+\"\\x3d; Path\\x3d\/; Domain\\x3d\"+a+\"; Expires\\x3dThu, 01 Jan 1970 00:00:01 GMT;\"})})();\u003C\/script\u003E"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":49
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E",["escape",["macro",28],8,16],".remove(",["escape",["macro",41],8,16],");\u003C\/script\u003E\n\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":50
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E",["escape",["macro",28],8,16],".remove(",["escape",["macro",29],8,16],");\u003C\/script\u003E\n\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":51
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_event":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E\"yes\"===",["escape",["macro",13],8,16],"\u0026\u0026\"Landing\"!==",["escape",["macro",51],8,16],"||",["escape",["macro",28],8,16],".remove(",["escape",["macro",33],8,16],");\u003C\/script\u003E\n\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":52
    },{
      "function":"__html",
      "metadata":["map"],
      "once_per_load":true,
      "vtp_html":["template","\u003Cscript type=\"text\/gtmscript\"\u003E(function(){if(",["escape",["macro",137],8,16],"){var b=",["escape",["macro",135],8,16],";if(b){var a=",["escape",["macro",28],8,16],";a.set(",["escape",["macro",41],8,16],",b,a.DURATIONS.day,a.POLICIES.analytics)}}})();\u003C\/script\u003E\n"],
      "vtp_supportDocumentWrite":false,
      "vtp_enableIframeMode":false,
      "vtp_enableEditJsMacroBehavior":false,
      "tag_id":19
    }],
  "predicates":[{
      "function":"_eq",
      "arg0":["macro",43],
      "arg1":"mg.pageview"
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"no|invalid"
    },{
      "function":"_re",
      "arg0":["macro",43],
      "arg1":".*"
    },{
      "function":"_eq",
      "arg0":["macro",91],
      "arg1":"CookieConsent"
    },{
      "function":"_eq",
      "arg0":["macro",43],
      "arg1":"mg.event"
    },{
      "function":"_eq",
      "arg0":["macro",91],
      "arg1":"Payment"
    },{
      "function":"_eq",
      "arg0":["macro",131],
      "arg1":"Success"
    },{
      "function":"_eq",
      "arg0":["macro",137],
      "arg1":"yes"
    },{
      "function":"_eq",
      "arg0":["macro",132],
      "arg1":"BootApp"
    },{
      "function":"_cn",
      "arg0":["macro",91],
      "arg1":"Boot"
    },{
      "function":"_eq",
      "arg0":["macro",34],
      "arg1":"yes"
    },{
      "function":"_re",
      "arg0":["macro",43],
      "arg1":"^mg\\..*"
    },{
      "function":"_re",
      "arg0":["macro",47],
      "arg1":"^\/signup\/.*|^\/welcome",
      "ignore_case":true
    },{
      "function":"_eq",
      "arg0":["macro",51],
      "arg1":"Landing"
    },{
      "function":"_eq",
      "arg0":["macro",13],
      "arg1":"yes"
    },{
      "function":"_eq",
      "arg0":["macro",43],
      "arg1":"gtm.js"
    },{
      "function":"_eq",
      "arg0":["macro",51],
      "arg1":"LoggedPage"
    },{
      "function":"_eq",
      "arg0":["macro",47],
      "arg1":"\/signup\/success"
    },{
      "function":"_re",
      "arg0":["macro",13],
      "arg1":"yes"
    }],
  "rules":[
    [["if",0],["add",3,16]],
    [["if",4],["unless",3],["add",4]],
    [["if",3,4],["add",5,11,13,14,15,16]],
    [["if",4,5,6,7],["add",6]],
    [["if",4,8,9,10],["add",7]],
    [["if",11],["add",8,9]],
    [["if",2],["add",1,12,0,2]],
    [["if",15],["add",1,12,0,2]],
    [["if",0,13,17],["add",10],["block",16]],
    [["if",1,2],["block",3,4,6,7]],
    [["if",2],["unless",12,13],["block",8]],
    [["if",2],["unless",14],["block",8,9,2]],
    [["if",2],["unless",16],["block",9]],
    [["if",2,18],["block",11,13,14,15]],
    [["if",2],["unless",13],["block",16]]]
},
"runtime":[
[],[]
]



};
var aa,ba=this||self,da=/^[\w+/_-]+[=]{0,2}$/,ea=null;var fa=function(){},ha=function(a){return"function"==typeof a},ia=function(a){return"string"==typeof a},ja=function(a){return"number"==typeof a&&!isNaN(a)},ka=function(a){return"[object Array]"==Object.prototype.toString.call(Object(a))},la=function(a,b){if(Array.prototype.indexOf){var c=a.indexOf(b);return"number"==typeof c?c:-1}for(var d=0;d<a.length;d++)if(a[d]===b)return d;return-1},ma=function(a,b){if(a&&ka(a))for(var c=0;c<a.length;c++)if(a[c]&&b(a[c]))return a[c]},oa=function(a,b){if(!ja(a)||
!ja(b)||a>b)a=0,b=2147483647;return Math.floor(Math.random()*(b-a+1)+a)},qa=function(a,b){for(var c=new pa,d=0;d<a.length;d++)c.set(a[d],!0);for(var e=0;e<b.length;e++)if(c.get(b[e]))return!0;return!1},ra=function(a,b){for(var c in a)Object.prototype.hasOwnProperty.call(a,c)&&b(c,a[c])},sa=function(a){return Math.round(Number(a))||0},ta=function(a){return"false"==String(a).toLowerCase()?!1:!!a},ua=function(a){var b=[];if(ka(a))for(var c=0;c<a.length;c++)b.push(String(a[c]));return b},va=function(a){return a?
a.replace(/^\s+|\s+$/g,""):""},wa=function(){return(new Date).getTime()},pa=function(){this.prefix="gtm.";this.values={}};pa.prototype.set=function(a,b){this.values[this.prefix+a]=b};pa.prototype.get=function(a){return this.values[this.prefix+a]};pa.prototype.contains=function(a){return void 0!==this.get(a)};
var xa=function(a,b,c){return a&&a.hasOwnProperty(b)?a[b]:c},ya=function(a){var b=!1;return function(){if(!b)try{a()}catch(c){}b=!0}},za=function(a,b){for(var c in b)b.hasOwnProperty(c)&&(a[c]=b[c])},Aa=function(a){for(var b in a)if(a.hasOwnProperty(b))return!0;return!1},Da=function(a,b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]),c.push.apply(c,b[a[d]]||[]);return c};/*
 jQuery v1.9.1 (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license. */
var Ea=/\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,Fa=function(a){if(null==a)return String(a);var b=Ea.exec(Object.prototype.toString.call(Object(a)));return b?b[1].toLowerCase():"object"},Ga=function(a,b){return Object.prototype.hasOwnProperty.call(Object(a),b)},Ha=function(a){if(!a||"object"!=Fa(a)||a.nodeType||a==a.window)return!1;try{if(a.constructor&&!Ga(a,"constructor")&&!Ga(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}for(var b in a);return void 0===
b||Ga(a,b)},f=function(a,b){var c=b||("array"==Fa(a)?[]:{}),d;for(d in a)if(Ga(a,d)){var e=a[d];"array"==Fa(e)?("array"!=Fa(c[d])&&(c[d]=[]),c[d]=f(e,c[d])):Ha(e)?(Ha(c[d])||(c[d]={}),c[d]=f(e,c[d])):c[d]=e}return c};var u=window,C=document,Ia=navigator,Ja=C.currentScript&&C.currentScript.src,Ka=function(a,b){var c=u[a];u[a]=void 0===c?b:c;return u[a]},La=function(a,b){b&&(a.addEventListener?a.onload=b:a.onreadystatechange=function(){a.readyState in{loaded:1,complete:1}&&(a.onreadystatechange=null,b())})},Ma=function(a,b,c){var d=C.createElement("script");d.type="text/javascript";d.async=!0;d.src=a;La(d,b);c&&(d.onerror=c);var e;if(null===ea)b:{var g=ba.document,h=g.querySelector&&g.querySelector("script[nonce]");
if(h){var k=h.nonce||h.getAttribute("nonce");if(k&&da.test(k)){ea=k;break b}}ea=""}e=ea;e&&d.setAttribute("nonce",e);var l=C.getElementsByTagName("script")[0]||C.body||C.head;l.parentNode.insertBefore(d,l);return d},Na=function(){if(Ja){var a=Ja.toLowerCase();if(0===a.indexOf("https://"))return 2;if(0===a.indexOf("http://"))return 3}return 1},Oa=function(a,b){var c=C.createElement("iframe");c.height="0";c.width="0";c.style.display="none";c.style.visibility="hidden";var d=C.body&&C.body.lastChild||
C.body||C.head;d.parentNode.insertBefore(c,d);La(c,b);void 0!==a&&(c.src=a);return c},Pa=function(a,b,c){var d=new Image(1,1);d.onload=function(){d.onload=null;b&&b()};d.onerror=function(){d.onerror=null;c&&c()};d.src=a;return d},Qa=function(a,b,c,d){a.addEventListener?a.addEventListener(b,c,!!d):a.attachEvent&&a.attachEvent("on"+b,c)},Ra=function(a,b,c){a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)},D=function(a){u.setTimeout(a,0)},Sa=function(a,b){return a&&
b&&a.attributes&&a.attributes[b]?a.attributes[b].value:null},Ta=function(a){var b=a.innerText||a.textContent||"";b&&" "!=b&&(b=b.replace(/^[\s\xa0]+|[\s\xa0]+$/g,""));b&&(b=b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g," "));return b},Ua=function(a){var b=C.createElement("div");b.innerHTML="A<div>"+a+"</div>";b=b.lastChild;for(var c=[];b.firstChild;)c.push(b.removeChild(b.firstChild));return c},Ya=function(a,b,c){c=c||100;for(var d={},e=0;e<b.length;e++)d[b[e]]=!0;for(var g=a,h=0;g&&h<=c;h++){if(d[String(g.tagName).toLowerCase()])return g;
g=g.parentElement}return null},Za=function(a,b){var c=a[b];c&&"string"===typeof c.animVal&&(c=c.animVal);return c};var $a=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;var ab={},bb=function(a,b){ab[a]=ab[a]||[];ab[a][b]=!0},cb=function(a){for(var b=[],c=ab[a]||[],d=0;d<c.length;d++)c[d]&&(b[Math.floor(d/6)]^=1<<d%6);for(var e=0;e<b.length;e++)b[e]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(b[e]||0);return b.join("")};var db=/:[0-9]+$/,eb=function(a,b,c){for(var d=a.split("&"),e=0;e<d.length;e++){var g=d[e].split("=");if(decodeURIComponent(g[0]).replace(/\+/g," ")===b){var h=g.slice(1).join("=");return c?h:decodeURIComponent(h).replace(/\+/g," ")}}},hb=function(a,b,c,d,e){b&&(b=String(b).toLowerCase());if("protocol"===b||"port"===b)a.protocol=fb(a.protocol)||fb(u.location.protocol);"port"===b?a.port=String(Number(a.hostname?a.port:u.location.port)||("http"==a.protocol?80:"https"==a.protocol?443:"")):"host"===b&&
(a.hostname=(a.hostname||u.location.hostname).replace(db,"").toLowerCase());var g=b,h,k=fb(a.protocol);g&&(g=String(g).toLowerCase());switch(g){case "url_no_fragment":h=gb(a);break;case "protocol":h=k;break;case "host":h=a.hostname.replace(db,"").toLowerCase();if(c){var l=/^www\d*\./.exec(h);l&&l[0]&&(h=h.substr(l[0].length))}break;case "port":h=String(Number(a.port)||("http"==k?80:"https"==k?443:""));break;case "path":a.pathname||a.hostname||bb("TAGGING",1);h="/"==a.pathname.substr(0,1)?a.pathname:
"/"+a.pathname;var m=h.split("/");0<=la(d||[],m[m.length-1])&&(m[m.length-1]="");h=m.join("/");break;case "query":h=a.search.replace("?","");e&&(h=eb(h,e,void 0));break;case "extension":var n=a.pathname.split(".");h=1<n.length?n[n.length-1]:"";h=h.split("/")[0];break;case "fragment":h=a.hash.replace("#","");break;default:h=a&&a.href}return h},fb=function(a){return a?a.replace(":","").toLowerCase():""},gb=function(a){var b="";if(a&&a.href){var c=a.href.indexOf("#");b=0>c?a.href:a.href.substr(0,c)}return b},
jb=function(a){var b=C.createElement("a");a&&(b.href=a);var c=b.pathname;"/"!==c[0]&&(a||bb("TAGGING",1),c="/"+c);var d=b.hostname.replace(db,"");return{href:b.href,protocol:b.protocol,host:b.host,hostname:d,pathname:c,search:b.search,hash:b.hash,port:b.port}};var kb=function(a,b,c){for(var d=[],e=String(b||document.cookie).split(";"),g=0;g<e.length;g++){var h=e[g].split("="),k=h[0].replace(/^\s*|\s*$/g,"");if(k&&k==a){var l=h.slice(1).join("=").replace(/^\s*|\s*$/g,"");l&&c&&(l=decodeURIComponent(l));d.push(l)}}return d},nb=function(a,b,c,d){var e=lb(a,d);if(1===e.length)return e[0].id;if(0!==e.length){e=mb(e,function(g){return g.Ib},b);if(1===e.length)return e[0].id;e=mb(e,function(g){return g.eb},c);return e[0]?e[0].id:void 0}};
function ob(a,b,c){var d=document.cookie;document.cookie=a;var e=document.cookie;return d!=e||void 0!=c&&0<=kb(b,e).indexOf(c)}
var rb=function(a,b,c,d,e,g){d=d||"auto";var h={path:c||"/"};e&&(h.expires=e);"none"!==d&&(h.domain=d);var k;a:{var l=b,m;if(void 0==l)m=a+"=deleted; expires="+(new Date(0)).toUTCString();else{g&&(l=encodeURIComponent(l));var n=l;n&&1200<n.length&&(n=n.substring(0,1200));l=n;m=a+"="+l}var p=void 0,t=void 0,q;for(q in h)if(h.hasOwnProperty(q)){var r=h[q];if(null!=r)switch(q){case "secure":r&&(m+="; secure");break;case "domain":p=r;break;default:"path"==q&&(t=r),"expires"==q&&r instanceof Date&&(r=
r.toUTCString()),m+="; "+q+"="+r}}if("auto"===p){for(var v=pb(),w=0;w<v.length;++w){var x="none"!=v[w]?v[w]:void 0;if(!qb(x,t)&&ob(m+(x?"; domain="+x:""),a,l)){k=!0;break a}}k=!1}else p&&"none"!=p&&(m+="; domain="+p),k=!qb(p,t)&&ob(m,a,l)}return k};function mb(a,b,c){for(var d=[],e=[],g,h=0;h<a.length;h++){var k=a[h],l=b(k);l===c?d.push(k):void 0===g||l<g?(e=[k],g=l):l===g&&e.push(k)}return 0<d.length?d:e}
function lb(a,b){for(var c=[],d=kb(a),e=0;e<d.length;e++){var g=d[e].split("."),h=g.shift();if(!b||-1!==b.indexOf(h)){var k=g.shift();k&&(k=k.split("-"),c.push({id:g.join("."),Ib:1*k[0]||1,eb:1*k[1]||1}))}}return c}
var tb=/^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,ub=/(^|\.)doubleclick\.net$/i,qb=function(a,b){return ub.test(document.location.hostname)||"/"===b&&tb.test(a)},pb=function(){var a=[],b=document.location.hostname.split(".");if(4===b.length){var c=b[b.length-1];if(parseInt(c,10).toString()===c)return["none"]}for(var d=b.length-2;0<=d;d--)a.push(b.slice(d).join("."));a.push("none");return a};
var vb=[],wb={"\x00":"&#0;",'"':"&quot;","&":"&amp;","'":"&#39;","<":"&lt;",">":"&gt;","\t":"&#9;","\n":"&#10;","\x0B":"&#11;","\f":"&#12;","\r":"&#13;"," ":"&#32;","-":"&#45;","/":"&#47;","=":"&#61;","`":"&#96;","\u0085":"&#133;","\u00a0":"&#160;","\u2028":"&#8232;","\u2029":"&#8233;"},xb=function(a){return wb[a]},yb=/[\x00\x22\x26\x27\x3c\x3e]/g;var Cb=/[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\\\x85\u2028\u2029]/g,Db={"\x00":"\\x00","\b":"\\x08","\t":"\\t","\n":"\\n","\x0B":"\\x0b",
"\f":"\\f","\r":"\\r",'"':"\\x22","&":"\\x26","'":"\\x27","/":"\\/","<":"\\x3c","=":"\\x3d",">":"\\x3e","\\":"\\\\","\u0085":"\\x85","\u2028":"\\u2028","\u2029":"\\u2029",$:"\\x24","(":"\\x28",")":"\\x29","*":"\\x2a","+":"\\x2b",",":"\\x2c","-":"\\x2d",".":"\\x2e",":":"\\x3a","?":"\\x3f","[":"\\x5b","]":"\\x5d","^":"\\x5e","{":"\\x7b","|":"\\x7c","}":"\\x7d"},Eb=function(a){return Db[a]};
vb[8]=function(a){if(null==a)return" null ";switch(typeof a){case "boolean":case "number":return" "+a+" ";default:return"'"+String(String(a)).replace(Cb,Eb)+"'"}};var Mb=/[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,Nb={"\x00":"%00","\u0001":"%01","\u0002":"%02","\u0003":"%03","\u0004":"%04","\u0005":"%05","\u0006":"%06","\u0007":"%07","\b":"%08","\t":"%09","\n":"%0A","\x0B":"%0B","\f":"%0C","\r":"%0D","\u000e":"%0E","\u000f":"%0F","\u0010":"%10",
"\u0011":"%11","\u0012":"%12","\u0013":"%13","\u0014":"%14","\u0015":"%15","\u0016":"%16","\u0017":"%17","\u0018":"%18","\u0019":"%19","\u001a":"%1A","\u001b":"%1B","\u001c":"%1C","\u001d":"%1D","\u001e":"%1E","\u001f":"%1F"," ":"%20",'"':"%22","'":"%27","(":"%28",")":"%29","<":"%3C",">":"%3E","\\":"%5C","{":"%7B","}":"%7D","\u007f":"%7F","\u0085":"%C2%85","\u00a0":"%C2%A0","\u2028":"%E2%80%A8","\u2029":"%E2%80%A9","\uff01":"%EF%BC%81","\uff03":"%EF%BC%83","\uff04":"%EF%BC%84","\uff06":"%EF%BC%86",
"\uff07":"%EF%BC%87","\uff08":"%EF%BC%88","\uff09":"%EF%BC%89","\uff0a":"%EF%BC%8A","\uff0b":"%EF%BC%8B","\uff0c":"%EF%BC%8C","\uff0f":"%EF%BC%8F","\uff1a":"%EF%BC%9A","\uff1b":"%EF%BC%9B","\uff1d":"%EF%BC%9D","\uff1f":"%EF%BC%9F","\uff20":"%EF%BC%A0","\uff3b":"%EF%BC%BB","\uff3d":"%EF%BC%BD"},Ob=function(a){return Nb[a]};vb[16]=function(a){return a};var Qb=[],Rb=[],Sb=[],Tb=[],Ub=[],Vb={},Wb,Yb,Zb,$b=function(a,b){var c={};c["function"]="__"+a;for(var d in b)b.hasOwnProperty(d)&&(c["vtp_"+d]=b[d]);return c},ac=function(a,b){var c=a["function"];if(!c)throw Error("Error: No function name given for function call.");var d=!!Vb[c],e={},g;for(g in a)a.hasOwnProperty(g)&&0===g.indexOf("vtp_")&&(e[d?g:g.substr(4)]=a[g]);return d?Vb[c](e):(void 0)(c,e,b)},cc=function(a,b,c){c=c||[];var d={},e;for(e in a)a.hasOwnProperty(e)&&(d[e]=bc(a[e],b,c));return d},
dc=function(a){var b=a["function"];if(!b)throw"Error: No function name given for function call.";var c=Vb[b];return c?c.priorityOverride||0:0},bc=function(a,b,c){if(ka(a)){var d;switch(a[0]){case "function_id":return a[1];case "list":d=[];for(var e=1;e<a.length;e++)d.push(bc(a[e],b,c));return d;case "macro":var g=a[1];if(c[g])return;var h=Qb[g];if(!h||b.Cc(h))return;c[g]=!0;try{var k=cc(h,b,c);k.vtp_gtmEventId=b.id;d=ac(k,b);Zb&&(d=Zb.Af(d,k))}catch(w){b.Yd&&b.Yd(w,Number(g)),d=!1}c[g]=!1;return d;
case "map":d={};for(var l=1;l<a.length;l+=2)d[bc(a[l],b,c)]=bc(a[l+1],b,c);return d;case "template":d=[];for(var m=!1,n=1;n<a.length;n++){var p=bc(a[n],b,c);Yb&&(m=m||p===Yb.wb);d.push(p)}return Yb&&m?Yb.Df(d):d.join("");case "escape":d=bc(a[1],b,c);if(Yb&&ka(a[1])&&"macro"===a[1][0]&&Yb.eg(a))return Yb.pg(d);d=String(d);for(var t=2;t<a.length;t++)vb[a[t]]&&(d=vb[a[t]](d));return d;case "tag":var q=a[1];if(!Tb[q])throw Error("Unable to resolve tag reference "+q+".");return d={Kd:a[2],index:q};case "zb":var r=
{arg0:a[2],arg1:a[3],ignore_case:a[5]};r["function"]=a[1];var v=ec(r,b,c);a[4]&&(v=!v);return v;default:throw Error("Attempting to expand unknown Value type: "+a[0]+".");}}return a},ec=function(a,b,c){try{return Wb(cc(a,b,c))}catch(d){JSON.stringify(a)}return null};var fc=function(){var a=function(b){return{toString:function(){return b}}};return{cd:a("convert_case_to"),dd:a("convert_false_to"),ed:a("convert_null_to"),fd:a("convert_true_to"),gd:a("convert_undefined_to"),Yg:a("debug_mode_metadata"),ja:a("function"),Pe:a("instance_name"),Qe:a("live_only"),Re:a("malware_disabled"),Se:a("metadata"),$g:a("original_vendor_template_id"),Te:a("once_per_event"),zd:a("once_per_load"),Ad:a("setup_tags"),Bd:a("tag_id"),Cd:a("teardown_tags")}}();var gc=null,jc=function(a){function b(p){for(var t=0;t<p.length;t++)d[p[t]]=!0}var c=[],d=[];gc=hc(a);for(var e=0;e<Rb.length;e++){var g=Rb[e],h=ic(g);if(h){for(var k=g.add||[],l=0;l<k.length;l++)c[k[l]]=!0;b(g.block||[])}else null===h&&b(g.block||[])}for(var m=[],n=0;n<Tb.length;n++)c[n]&&!d[n]&&(m[n]=!0);return m},ic=function(a){for(var b=a["if"]||[],c=0;c<b.length;c++){var d=gc(b[c]);if(!d)return null===d?null:!1}for(var e=a.unless||[],g=0;g<e.length;g++){var h=gc(e[g]);if(null===h)return null;
if(h)return!1}return!0},hc=function(a){var b=[];return function(c){void 0===b[c]&&(b[c]=ec(Sb[c],a));return b[c]}};/*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
for(var mc="floor ceil round max min abs pow sqrt".split(" "),nc=0;nc<mc.length;nc++)Math.hasOwnProperty(mc[nc]);var G={$b:"event_callback",Ma:"event_timeout",T:"gtag.config",M:"allow_ad_personalization_signals",O:"cookie_expires",La:"cookie_update",wa:"session_duration"};var Cc=/[A-Z]+/,Dc=/\s/,Ec=function(a){if(ia(a)&&(a=va(a),!Dc.test(a))){var b=a.indexOf("-");if(!(0>b)){var c=a.substring(0,b);if(Cc.test(c)){for(var d=a.substring(b+1).split("/"),e=0;e<d.length;e++)if(!d[e])return;return{id:a,prefix:c,containerId:c+"-"+d[0],ba:d}}}}},Gc=function(a){for(var b={},c=0;c<a.length;++c){var d=Ec(a[c]);d&&(b[d.id]=d)}Fc(b);var e=[];ra(b,function(g,h){e.push(h)});return e};
function Fc(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];"AW"===d.prefix&&d.ba[1]&&b.push(d.containerId)}for(var e=0;e<b.length;++e)delete a[b[e]]};var Hc={},Ic=null,Jc=Math.random();Hc.i="GTM-WPNZTTN";Hc.Ab="874";var Kc={__cl:!0,__ecl:!0,__ehl:!0,__evl:!0,__fal:!0,__fil:!0,__fsl:!0,__hl:!0,__jel:!0,__lcl:!0,__sdl:!0,__tl:!0,__ytl:!0,__paused:!0},Lc="www.googletagmanager.com/gtm.js";var Mc=Lc,Nc=null,Oc=null,Pc=null,Qc="//www.googletagmanager.com/a?id="+Hc.i+"&cv=121",Rc={},Sc={},Tc=function(){var a=Ic.sequence||0;Ic.sequence=a+1;return a};
var Uc=function(){return"&tc="+Tb.filter(function(a){return a}).length},cd=function(){Vc&&(u.clearTimeout(Vc),Vc=void 0);void 0===Wc||Xc[Wc]&&!Yc||(Zc[Wc]||$c.gg()||0>=ad--?(bb("GTM",1),Zc[Wc]=!0):($c.Bg(),Pa(bd()),Xc[Wc]=!0,Yc=""))},bd=function(){var a=Wc;if(void 0===a)return"";var b=cb("GTM"),c=cb("TAGGING");return[dd,Xc[a]?"":"&es=1",ed[a],b?"&u="+b:"",c?"&ut="+c:"",Uc(),Yc,"&z=0"].join("")},fd=function(){return[Qc,"&v=3&t=t","&pid="+oa(),"&rv="+Hc.Ab].join("")},gd="0.005000">
Math.random(),dd=fd(),hd=function(){dd=fd()},Xc={},Yc="",Wc=void 0,ed={},Zc={},Vc=void 0,$c=function(a,b){var c=0,d=0;return{gg:function(){if(c<a)return!1;wa()-d>=b&&(c=0);return c>=a},Bg:function(){wa()-d>=b&&(c=0);c++;d=wa()}}}(2,1E3),ad=1E3,id=function(a,b){if(gd&&!Zc[a]&&Wc!==a){cd();Wc=a;Yc="";var c;c=0===b.indexOf("gtm.")?encodeURIComponent(b):"*";ed[a]="&e="+c+"&eid="+a;Vc||(Vc=u.setTimeout(cd,500))}},jd=function(a,b,c){if(gd&&!Zc[a]&&b){a!==Wc&&(cd(),Wc=a);var d=String(b[fc.ja]||"").replace(/_/g,
"");0===d.indexOf("cvt")&&(d="cvt");var e=c+d;Yc=Yc?Yc+"."+e:"&tr="+e;Vc||(Vc=u.setTimeout(cd,500));2022<=bd().length&&cd()}};var kd={},ld=new pa,md={},nd={},rd={name:"dataLayer",set:function(a,b){f(od(a,b),md);pd()},get:function(a){return qd(a,2)},reset:function(){ld=new pa;md={};pd()}},qd=function(a,b){if(2!=b){var c=ld.get(a);if(gd){var d=sd(a);c!==d&&bb("GTM",5)}return c}return sd(a)},sd=function(a,b,c){var d=a.split("."),e=!1,g=void 0;return e?g:ud(d)},ud=function(a){for(var b=md,c=0;c<a.length;c++){if(null===b)return!1;if(void 0===b)break;b=b[a[c]]}return b};
var xd=function(a,b){nd.hasOwnProperty(a)||(ld.set(a,b),f(od(a,b),md),pd())},od=function(a,b){for(var c={},d=c,e=a.split("."),g=0;g<e.length-1;g++)d=d[e[g]]={};d[e[e.length-1]]=b;return c},pd=function(a){ra(nd,function(b,c){ld.set(b,c);f(od(b,void 0),md);f(od(b,c),md);a&&delete nd[b]})},yd=function(a,b,c){kd[a]=kd[a]||{};var d=1!==c?sd(b):ld.get(b);"array"===Fa(d)||"object"===Fa(d)?kd[a][b]=f(d):kd[a][b]=d},zd=function(a,b){if(kd[a])return kd[a][b]};var Ad=function(){var a=!1;return a};var H=function(a,b,c,d){return(2===Bd()||d||"http:"!=u.location.protocol?a:b)+c},Bd=function(){var a=Na(),b;if(1===a)a:{var c=Mc;c=c.toLowerCase();for(var d="https://"+c,e="http://"+c,g=1,h=C.getElementsByTagName("script"),k=0;k<h.length&&100>k;k++){var l=h[k].src;if(l){l=l.toLowerCase();if(0===l.indexOf(e)){b=3;break a}1===g&&0===l.indexOf(d)&&(g=2)}}b=g}else b=a;return b};var Ld=new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),Md={cl:["ecl"],customPixels:["nonGooglePixels"],ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],customScripts:["html","customPixels","nonGooglePixels","nonGoogleScripts","nonGoogleIframes"],nonGooglePixels:[],nonGoogleScripts:["nonGooglePixels"],nonGoogleIframes:["nonGooglePixels"]},Nd={cl:["ecl"],customPixels:["customScripts","html"],
ecl:["cl"],ehl:["hl"],hl:["ehl"],html:["customScripts"],customScripts:["html"],nonGooglePixels:["customPixels","customScripts","html","nonGoogleScripts","nonGoogleIframes"],nonGoogleScripts:["customScripts","html"],nonGoogleIframes:["customScripts","html","nonGoogleScripts"]},Od="google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");
var Qd=function(a){var b=qd("gtm.whitelist");b&&bb("GTM",9);var c=b&&Da(ua(b),Md),d=qd("gtm.blacklist");d||(d=qd("tagTypeBlacklist"))&&bb("GTM",3);
d?bb("GTM",8):d=[];Pd()&&(d=ua(d),d.push("nonGooglePixels","nonGoogleScripts"));0<=la(ua(d),"google")&&bb("GTM",2);var e=d&&Da(ua(d),Nd),g={};return function(h){var k=h&&h[fc.ja];if(!k||"string"!=typeof k)return!0;k=k.replace(/^_*/,"");if(void 0!==g[k])return g[k];var l=Sc[k]||[],m=a(k);if(b){var n;if(n=m)a:{if(0>la(c,k))if(l&&0<l.length)for(var p=0;p<l.length;p++){if(0>
la(c,l[p])){bb("GTM",11);n=!1;break a}}else{n=!1;break a}n=!0}m=n}var t=!1;if(d){var q=0<=la(e,k);if(q)t=q;else{var r=qa(e,l||[]);r&&bb("GTM",10);t=r}}var v=!m||t;v||!(0<=la(l,"sandboxedScripts"))||c&&-1!==la(c,"sandboxedScripts")||(v=qa(e,Od));return g[k]=v}},Pd=function(){return Ld.test(u.location&&u.location.hostname)};var Rd={Af:function(a,b){b[fc.cd]&&"string"===typeof a&&(a=1==b[fc.cd]?a.toLowerCase():a.toUpperCase());b.hasOwnProperty(fc.ed)&&null===a&&(a=b[fc.ed]);b.hasOwnProperty(fc.gd)&&void 0===a&&(a=b[fc.gd]);b.hasOwnProperty(fc.fd)&&!0===a&&(a=b[fc.fd]);b.hasOwnProperty(fc.dd)&&!1===a&&(a=b[fc.dd]);return a}};var Sd={active:!0,isWhitelisted:function(){return!0}},Td=function(a){var b=Ic.zones;!b&&a&&(b=Ic.zones=a());return b};var Ud=!1,Vd=0,Wd=[];function Xd(a){if(!Ud){var b=C.createEventObject,c="complete"==C.readyState,d="interactive"==C.readyState;if(!a||"readystatechange"!=a.type||c||!b&&d){Ud=!0;for(var e=0;e<Wd.length;e++)D(Wd[e])}Wd.push=function(){for(var g=0;g<arguments.length;g++)D(arguments[g]);return 0}}}function Yd(){if(!Ud&&140>Vd){Vd++;try{C.documentElement.doScroll("left"),Xd()}catch(a){u.setTimeout(Yd,50)}}}var Zd=function(a){Ud?a():Wd.push(a)};var $d={},ae={},be=function(a,b,c,d){if(!ae[a]||Kc[b]||"__zone"===b)return-1;var e={};Ha(d)&&(e=f(d,e));e.id=c;e.status="timeout";return ae[a].tags.push(e)-1},ce=function(a,b,c,d){if(ae[a]){var e=ae[a].tags[b];e&&(e.status=c,e.executionTime=d)}};function de(a){for(var b=$d[a]||[],c=0;c<b.length;c++)b[c]();$d[a]={push:function(d){d(Hc.i,ae[a])}}}
var ge=function(a,b,c){ae[a]={tags:[]};ha(b)&&ee(a,b);c&&u.setTimeout(function(){return de(a)},Number(c));return fe(a)},ee=function(a,b){$d[a]=$d[a]||[];$d[a].push(ya(function(){return D(function(){b(Hc.i,ae[a])})}))};function fe(a){var b=0,c=0,d=!1;return{add:function(){c++;return ya(function(){b++;d&&b>=c&&de(a)})},hf:function(){d=!0;b>=c&&de(a)}}};var he=function(){function a(d){return!ja(d)||0>d?0:d}if(!Ic._li&&u.performance&&u.performance.timing){var b=u.performance.timing.navigationStart,c=ja(rd.get("gtm.start"))?rd.get("gtm.start"):0;Ic._li={cst:a(c-b),cbt:a(Oc-b)}}};var le=!1,me=function(){return u.GoogleAnalyticsObject&&u[u.GoogleAnalyticsObject]},ne=!1;
var oe=function(a){u.GoogleAnalyticsObject||(u.GoogleAnalyticsObject=a||"ga");var b=u.GoogleAnalyticsObject;if(u[b])u.hasOwnProperty(b)||bb("GTM",12);else{var c=function(){c.q=c.q||[];c.q.push(arguments)};c.l=Number(new Date);u[b]=c}he();return u[b]},pe=function(a,b,c,d){b=String(b).replace(/\s+/g,"").split(",");var e=me();e(a+"require","linker");e(a+"linker:autoLink",b,c,d)};
var re=function(){},qe=function(){return u.GoogleAnalyticsObject||"ga"};var ye=function(a){};function xe(a,b){a.containerId=Hc.i;var c={type:"GENERIC",value:a};b.length&&(c.trace=b);return c};function ze(a,b,c,d){var e=Tb[a],g=Ae(a,b,c,d);if(!g)return null;var h=bc(e[fc.Ad],c,[]);if(h&&h.length){var k=h[0];g=ze(k.index,{I:g,R:1===k.Kd?b.terminate:g,terminate:b.terminate},c,d)}return g}
function Ae(a,b,c,d){function e(){if(g[fc.Re])k();else{var w=cc(g,c,[]),x=be(c.id,String(g[fc.ja]),Number(g[fc.Bd]),w[fc.Se]),y=!1;w.vtp_gtmOnSuccess=function(){if(!y){y=!0;var A=wa()-B;jd(c.id,Tb[a],"5");ce(c.id,x,"success",A);h()}};w.vtp_gtmOnFailure=function(){if(!y){y=!0;var A=wa()-B;jd(c.id,Tb[a],"6");ce(c.id,x,"failure",A);k()}};w.vtp_gtmTagId=g.tag_id;
w.vtp_gtmEventId=c.id;jd(c.id,g,"1");var z=function(A){var E=wa()-B;ye(A);jd(c.id,g,"7");ce(c.id,x,"exception",E);y||(y=!0,k())};var B=wa();try{ac(w,c)}catch(A){z(A)}}}var g=Tb[a],h=b.I,k=b.R,l=b.terminate;if(c.Cc(g))return null;var m=bc(g[fc.Cd],c,[]);if(m&&m.length){var n=m[0],p=ze(n.index,{I:h,R:k,terminate:l},c,d);if(!p)return null;h=p;k=2===n.Kd?l:p}if(g[fc.zd]||g[fc.Te]){var t=g[fc.zd]?Ub:c.Lg,q=h,r=k;if(!t[a]){e=ya(e);var v=Be(a,t,e);h=v.I;k=v.R}return function(){t[a](q,r)}}return e}
function Be(a,b,c){var d=[],e=[];b[a]=Ce(d,e,c);return{I:function(){b[a]=De;for(var g=0;g<d.length;g++)d[g]()},R:function(){b[a]=Ee;for(var g=0;g<e.length;g++)e[g]()}}}function Ce(a,b,c){return function(d,e){a.push(d);b.push(e);c()}}function De(a){a()}function Ee(a,b){b()};var He=function(a,b){for(var c=[],d=0;d<Tb.length;d++)if(a.ab[d]){var e=Tb[d];var g=b.add();try{var h=ze(d,{I:g,R:g,terminate:g},a,d);h?c.push({qe:d,ee:dc(e),Lf:h}):(Fe(d,a),g())}catch(l){g()}}b.hf();c.sort(Ge);for(var k=0;k<c.length;k++)c[k].Lf();return 0<c.length};function Ge(a,b){var c,d=b.ee,e=a.ee;c=d>e?1:d<e?-1:0;var g;if(0!==c)g=c;else{var h=a.qe,k=b.qe;g=h>k?1:h<k?-1:0}return g}
function Fe(a,b){if(!gd)return;var c=function(d){var e=b.Cc(Tb[d])?"3":"4",g=bc(Tb[d][fc.Ad],b,[]);g&&g.length&&c(g[0].index);jd(b.id,Tb[d],e);var h=bc(Tb[d][fc.Cd],b,[]);h&&h.length&&c(h[0].index)};c(a);}
var Ie=!1,Je=function(a,b,c,d,e){if("gtm.js"==b){if(Ie)return!1;Ie=!0}id(a,b);var g=ge(a,d,e);yd(a,"event",1);yd(a,"ecommerce",1);yd(a,"gtm");var h={id:a,name:b,Cc:Qd(c),ab:[],Lg:[],Yd:function(n){bb("GTM",6);ye(n)}};h.ab=jc(h);var k=He(h,g);"gtm.js"!==b&&"gtm.sync"!==b||re();if(!k)return k;for(var l=0;l<h.ab.length;l++)if(h.ab[l]){var m=
Tb[l];if(m&&!Kc[String(m[fc.ja])])return!0}return!1};var Le=function(a,b,c){var d=this;this.eventModel=a;this.targetConfig=b||{};this.globalConfig=c||{};this.getWithConfig=function(e){if(d.eventModel.hasOwnProperty(e))return d.eventModel[e];if(d.targetConfig.hasOwnProperty(e))return d.targetConfig[e];if(d.globalConfig.hasOwnProperty(e))return d.globalConfig[e]}};function Me(){var a=Ic;return a.gcq=a.gcq||new Ne}var Oe=function(a,b){Me().register(a,b)},Pe=function(){this.status=1;this.vc={};this.fe=null;this.Ud=!1},Qe=function(a,b,c,d,e){this.type=a;this.Qg=b;this.na=c||"";this.Cb=d;this.defer=e},Ne=function(){this.se={};this.Pd={};this.Wa=[]},Re=function(a,b){return a.se[b]=a.se[b]||new Pe},Se=function(a,b,c,d){var e=Re(a,d.na).fe;if(e){var g=f(c),h=f(Re(a,d.na).vc),k=f(a.Pd),l=new Le(g,h,k);try{e(b,d.Qg,l)}catch(m){}}};
Ne.prototype.register=function(a,b){3!==Re(this,a).status&&(Re(this,a).fe=b,Re(this,a).status=3,this.flush())};Ne.prototype.push=function(a,b,c,d){var e=Math.floor(wa()/1E3);if(c&&1===Re(this,c).status&&(Re(this,c).status=2,this.push("require",[],c),!Ad())){var g=encodeURIComponent(c);Ma(("http:"!=u.location.protocol?"https:":"http:")+("//www.googletagmanager.com/gtag/js?id="+g+"&l=dataLayer&cx=c"))}this.Wa.push(new Qe(a,e,c,b,d));d||this.flush()};
Ne.prototype.flush=function(a){for(var b=this;this.Wa.length;){var c=this.Wa[0];if(c.defer)c.defer=!1,this.Wa.push(c);else switch(c.type){case "require":if(3!==Re(this,c.na).status&&!a)return;break;case "set":ra(c.Cb[0],function(h,k){b.Pd[h]=k});break;case "config":var d=c.Cb[0],e=!!d[G.ub];delete d[G.ub];var g=Re(this,c.na);e||(g.vc={});g.Ud&&e||Se(this,G.T,d,c);g.Ud=!0;f(d,g.vc);break;case "event":Se(this,c.Cb[1],c.Cb[0],c)}this.Wa.shift()}};var Te={};var Ve=null,We={},Xe={},Ye,Ze=function(a,b){var c={event:a};b&&(c.eventModel=f(b),b[G.$b]&&(c.eventCallback=b[G.$b]),b[G.Ma]&&(c.eventTimeout=b[G.Ma]));return c};
var ef={config:function(a){},event:function(a){var b=a[1];if(ia(b)&&!(3<a.length)){var c;
if(2<a.length){if(!Ha(a[2]))return;c=a[2]}var d=Ze(b,c);return d}},js:function(a){if(2==a.length&&a[1].getTime)return{event:"gtm.js","gtm.start":a[1].getTime()}},policy:function(a){if(3===a.length){var b=a[1],c=a[2];Te[b]||(Te[b]=[]);Te[b].push(c)}},set:function(a){var b;2==a.length&&Ha(a[1])?b=f(a[1]):3==a.length&&ia(a[1])&&(b={},b[a[1]]=a[2]);if(b){b._clear=!0;return b}}},ff={policy:!0};var hf=function(a){return gf?C.querySelectorAll(a):null},jf=function(a,b){if(!gf)return null;if(Element.prototype.closest)try{return a.closest(b)}catch(e){return null}var c=Element.prototype.matches||Element.prototype.webkitMatchesSelector||Element.prototype.mozMatchesSelector||Element.prototype.msMatchesSelector||Element.prototype.oMatchesSelector,d=a;if(!C.documentElement.contains(d))return null;do{try{if(c.call(d,b))return d}catch(e){break}d=d.parentElement||d.parentNode}while(null!==d&&1===d.nodeType);
return null},kf=!1;if(C.querySelectorAll)try{var lf=C.querySelectorAll(":root");lf&&1==lf.length&&lf[0]==C.documentElement&&(kf=!0)}catch(a){}var gf=kf;var sf=function(a){if(rf(a))return a;this.Tg=a};sf.prototype.Sf=function(){return this.Tg};var rf=function(a){return!a||"object"!==Fa(a)||Ha(a)?!1:"getUntrustedUpdateValue"in a};sf.prototype.getUntrustedUpdateValue=sf.prototype.Sf;var tf=!1,uf=[];function vf(){if(!tf){tf=!0;for(var a=0;a<uf.length;a++)D(uf[a])}}var wf=function(a){tf?D(a):uf.push(a)};var xf=[],yf=!1,zf=function(a){return u["dataLayer"].push(a)},Af=function(a){var b=Ic["dataLayer"],c=b?b.subscribers:1,d=0;return function(){++d===c&&a()}},Cf=function(a){var b=a._clear;ra(a,function(g,h){"_clear"!==g&&(b&&xd(g,void 0),xd(g,h))});Nc||(Nc=a["gtm.start"]);var c=a.event;if(!c)return!1;var d=a["gtm.uniqueEventId"];d||(d=Tc(),a["gtm.uniqueEventId"]=d,xd("gtm.uniqueEventId",d));Pc=c;var e=Bf(a);
Pc=null;switch(c){case "gtm.init":bb("GTM",19),e&&bb("GTM",20)}return e};function Bf(a){var b=a.event,c=a["gtm.uniqueEventId"],d,e=Ic.zones;d=e?e.checkState(Hc.i,c):Sd;return d.active?Je(c,b,d.isWhitelisted,a.eventCallback,a.eventTimeout)?!0:!1:!1}
var Df=function(){for(var a=!1;!yf&&0<xf.length;){yf=!0;delete md.eventModel;pd();var b=xf.shift();if(null!=b){var c=rf(b);if(c){var d=b;b=rf(d)?d.getUntrustedUpdateValue():void 0;for(var e=["gtm.whitelist","gtm.blacklist","tagTypeBlacklist"],g=0;g<e.length;g++){var h=e[g],k=qd(h,1);if(ka(k)||Ha(k))k=f(k);nd[h]=k}}try{if(ha(b))try{b.call(rd)}catch(v){}else if(ka(b)){var l=b;if(ia(l[0])){var m=
l[0].split("."),n=m.pop(),p=l.slice(1),t=qd(m.join("."),2);if(void 0!==t&&null!==t)try{t[n].apply(t,p)}catch(v){}}}else{var q=b;if(q&&("[object Arguments]"==Object.prototype.toString.call(q)||Object.prototype.hasOwnProperty.call(q,"callee"))){a:{if(b.length&&ia(b[0])){var r=ef[b[0]];if(r&&(!c||!ff[b[0]])){b=r(b);break a}}b=void 0}if(!b){yf=!1;continue}}a=Cf(b)||a}}finally{c&&pd(!0)}}yf=!1}
return!a},Ef=function(){var a=Df();try{var b=Hc.i,c=u["dataLayer"].hide;if(c&&void 0!==c[b]&&c.end){c[b]=!1;var d=!0,e;for(e in c)if(c.hasOwnProperty(e)&&!0===c[e]){d=!1;break}d&&(c.end(),c.end=null)}}catch(g){}return a},Ff=function(){var a=Ka("dataLayer",[]),b=Ka("google_tag_manager",{});b=b["dataLayer"]=b["dataLayer"]||{};Zd(function(){b.gtmDom||(b.gtmDom=!0,a.push({event:"gtm.dom"}))});wf(function(){b.gtmLoad||(b.gtmLoad=!0,a.push({event:"gtm.load"}))});b.subscribers=(b.subscribers||
0)+1;var c=a.push;a.push=function(){var d;if(0<Ic.SANDBOXED_JS_SEMAPHORE){d=[];for(var e=0;e<arguments.length;e++)d[e]=new sf(arguments[e])}else d=[].slice.call(arguments,0);var g=c.apply(a,d);xf.push.apply(xf,d);if(300<this.length)for(bb("GTM",4);300<this.length;)this.shift();var h="boolean"!==typeof g||g;return Df()&&h};xf.push.apply(xf,a.slice(0));D(Ef)};var Gf;var bg={};bg.wb=new String("undefined");
var cg=function(a){this.resolve=function(b){for(var c=[],d=0;d<a.length;d++)c.push(a[d]===bg.wb?b:a[d]);return c.join("")}};cg.prototype.toString=function(){return this.resolve("undefined")};cg.prototype.valueOf=cg.prototype.toString;bg.Ue=cg;bg.kc={};bg.Df=function(a){return new cg(a)};var dg={};bg.Cg=function(a,b){var c=Tc();dg[c]=[a,b];return c};bg.Hd=function(a){var b=a?0:1;return function(c){var d=dg[c];if(d&&"function"===typeof d[b])d[b]();dg[c]=void 0}};bg.eg=function(a){for(var b=!1,c=!1,
d=2;d<a.length;d++)b=b||8===a[d],c=c||16===a[d];return b&&c};bg.pg=function(a){if(a===bg.wb)return a;var b=Tc();bg.kc[b]=a;return'google_tag_manager["'+Hc.i+'"].macro('+b+")"};bg.ig=function(a,b,c){a instanceof bg.Ue&&(a=a.resolve(bg.Cg(b,c)),b=fa);return{Ac:a,I:b}};var eg=function(a,b,c){function d(g,h){var k=g[h];return k}var e={event:b,"gtm.element":a,"gtm.elementClasses":d(a,"className"),"gtm.elementId":a["for"]||Sa(a,"id")||"","gtm.elementTarget":a.formTarget||d(a,"target")||""};c&&(e["gtm.triggers"]=c.join(","));e["gtm.elementUrl"]=(a.attributes&&a.attributes.formaction?a.formAction:"")||a.action||d(a,"href")||a.src||a.code||a.codebase||
"";return e},fg=function(a){Ic.hasOwnProperty("autoEventsSettings")||(Ic.autoEventsSettings={});var b=Ic.autoEventsSettings;b.hasOwnProperty(a)||(b[a]={});return b[a]},gg=function(a,b,c){fg(a)[b]=c},hg=function(a,b,c,d){var e=fg(a),g=xa(e,b,d);e[b]=c(g)},ig=function(a,b,c){var d=fg(a);return xa(d,b,c)};var jg=function(){for(var a=Ia.userAgent+(C.cookie||"")+(C.referrer||""),b=a.length,c=u.history.length;0<c;)a+=c--^b++;var d=1,e,g,h;if(a)for(d=0,g=a.length-1;0<=g;g--)h=a.charCodeAt(g),d=(d<<6&268435455)+h+(h<<14),e=d&266338304,d=0!=e?d^e>>21:d;return[Math.round(2147483647*Math.random())^d&2147483647,Math.round(wa()/1E3)].join(".")},mg=function(a,b,c,d){var e=kg(b);return nb(a,e,lg(c),d)},ng=function(a,b,c,d){var e=""+kg(c),g=lg(d);1<g&&(e+="-"+g);return[b,e,a].join(".")},kg=function(a){if(!a)return 1;
a=0===a.indexOf(".")?a.substr(1):a;return a.split(".").length},lg=function(a){if(!a||"/"===a)return 1;"/"!==a[0]&&(a="/"+a);"/"!==a[a.length-1]&&(a+="/");return a.split("/").length-1};var og=["1"],pg={},tg=function(a,b,c,d){var e=qg(a);pg[e]||rg(e,b,c)||(sg(e,jg(),b,c,d),rg(e,b,c))};function sg(a,b,c,d,e){var g=ng(b,"1",d,c);rb(a,g,c,d,0==e?void 0:new Date(wa()+1E3*(void 0==e?7776E3:e)))}function rg(a,b,c){var d=mg(a,b,c,og);d&&(pg[a]=d);return d}function qg(a){return(a||"_gcl")+"_au"};var ug=function(){for(var a=[],b=C.cookie.split(";"),c=/^\s*_gac_(UA-\d+-\d+)=\s*(.+?)\s*$/,d=0;d<b.length;d++){var e=b[d].match(c);e&&a.push({Wc:e[1],value:e[2]})}var g={};if(!a||!a.length)return g;for(var h=0;h<a.length;h++){var k=a[h].value.split(".");"1"==k[0]&&3==k.length&&k[1]&&(g[a[h].Wc]||(g[a[h].Wc]=[]),g[a[h].Wc].push({timestamp:k[1],Pf:k[2]}))}return g};function vg(){for(var a=wg,b={},c=0;c<a.length;++c)b[a[c]]=c;return b}function xg(){var a="ABCDEFGHIJKLMNOPQRSTUVWXYZ";a+=a.toLowerCase()+"0123456789-_";return a+"."}
var wg,yg,zg=function(a){wg=wg||xg();yg=yg||vg();for(var b=[],c=0;c<a.length;c+=3){var d=c+1<a.length,e=c+2<a.length,g=a.charCodeAt(c),h=d?a.charCodeAt(c+1):0,k=e?a.charCodeAt(c+2):0,l=g>>2,m=(g&3)<<4|h>>4,n=(h&15)<<2|k>>6,p=k&63;e||(p=64,d||(n=64));b.push(wg[l],wg[m],wg[n],wg[p])}return b.join("")},Ag=function(a){function b(l){for(;d<a.length;){var m=a.charAt(d++),n=yg[m];if(null!=n)return n;if(!/^[\s\xa0]*$/.test(m))throw Error("Unknown base64 encoding at char: "+m);}return l}wg=wg||xg();yg=yg||
vg();for(var c="",d=0;;){var e=b(-1),g=b(0),h=b(64),k=b(64);if(64===k&&-1===e)return c;c+=String.fromCharCode(e<<2|g>>4);64!=h&&(c+=String.fromCharCode(g<<4&240|h>>2),64!=k&&(c+=String.fromCharCode(h<<6&192|k)))}};var Bg;function Cg(a,b){if(!a||b===C.location.hostname)return!1;for(var c=0;c<a.length;c++)if(a[c]instanceof RegExp){if(a[c].test(b))return!0}else if(0<=b.indexOf(a[c]))return!0;return!1}
var Gg=function(){var a=Dg,b=Eg,c=Fg(),d=function(h){a(h.target||h.srcElement||{})},e=function(h){b(h.target||h.srcElement||{})};if(!c.init){Qa(C,"mousedown",d);Qa(C,"keyup",d);Qa(C,"submit",e);var g=HTMLFormElement.prototype.submit;HTMLFormElement.prototype.submit=function(){b(this);g.call(this)};c.init=!0}},Fg=function(){var a=Ka("google_tag_data",{}),b=a.gl;b&&b.decorators||(b={decorators:[]},a.gl=b);return b};var Hg=/(.*?)\*(.*?)\*(.*)/,Ig=/^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,Jg=/^(?:www\.|m\.|amp\.)+/,Kg=/([^?#]+)(\?[^#]*)?(#.*)?/,Lg=/(.*?)(^|&)_gl=([^&]*)&?(.*)/,Ng=function(a){var b=[],c;for(c in a)if(a.hasOwnProperty(c)){var d=a[c];void 0!==d&&d===d&&null!==d&&"[object Object]"!==d.toString()&&(b.push(c),b.push(zg(String(d))))}var e=b.join("*");return["1",Mg(e),e].join("*")},Mg=function(a,b){var c=[window.navigator.userAgent,(new Date).getTimezoneOffset(),window.navigator.userLanguage||
window.navigator.language,Math.floor((new Date).getTime()/60/1E3)-(void 0===b?0:b),a].join("*"),d;if(!(d=Bg)){for(var e=Array(256),g=0;256>g;g++){for(var h=g,k=0;8>k;k++)h=h&1?h>>>1^3988292384:h>>>1;e[g]=h}d=e}Bg=d;for(var l=4294967295,m=0;m<c.length;m++)l=l>>>8^Bg[(l^c.charCodeAt(m))&255];return((l^-1)>>>0).toString(36)},Pg=function(){return function(a){var b=jb(u.location.href),c=b.search.replace("?",""),d=eb(c,"_gl",!0)||"";a.query=Og(d)||{};var e=hb(b,"fragment").match(Lg);a.fragment=Og(e&&e[3]||
"")||{}}},Qg=function(){var a=Pg(),b=Fg();b.data||(b.data={query:{},fragment:{}},a(b.data));var c={},d=b.data;d&&(za(c,d.query),za(c,d.fragment));return c},Og=function(a){var b;b=void 0===b?3:b;try{if(a){var c;a:{for(var d=a,e=0;3>e;++e){var g=Hg.exec(d);if(g){c=g;break a}d=decodeURIComponent(d)}c=void 0}var h=c;if(h&&"1"===h[1]){var k=h[3],l;a:{for(var m=h[2],n=0;n<b;++n)if(m===Mg(k,n)){l=!0;break a}l=!1}if(l){for(var p={},t=k?k.split("*"):[],q=0;q<t.length;q+=2)p[t[q]]=Ag(t[q+1]);return p}}}}catch(r){}};
function Rg(a,b,c){function d(m){var n=m,p=Lg.exec(n),t=n;if(p){var q=p[2],r=p[4];t=p[1];r&&(t=t+q+r)}m=t;var v=m.charAt(m.length-1);m&&"&"!==v&&(m+="&");return m+l}c=void 0===c?!1:c;var e=Kg.exec(b);if(!e)return"";var g=e[1],h=e[2]||"",k=e[3]||"",l="_gl="+a;c?k="#"+d(k.substring(1)):h="?"+d(h.substring(1));return""+g+h+k}
function Sg(a,b,c){for(var d={},e={},g=Fg().decorators,h=0;h<g.length;++h){var k=g[h];(!c||k.forms)&&Cg(k.domains,b)&&(k.fragment?za(e,k.callback()):za(d,k.callback()))}if(Aa(d)){var l=Ng(d);if(c){if(a&&a.action){var m=(a.method||"").toLowerCase();if("get"===m){for(var n=a.childNodes||[],p=!1,t=0;t<n.length;t++){var q=n[t];if("_gl"===q.name){q.setAttribute("value",l);p=!0;break}}if(!p){var r=C.createElement("input");r.setAttribute("type","hidden");r.setAttribute("name","_gl");r.setAttribute("value",
l);a.appendChild(r)}}else if("post"===m){var v=Rg(l,a.action);$a.test(v)&&(a.action=v)}}}else Tg(l,a,!1)}if(!c&&Aa(e)){var w=Ng(e);Tg(w,a,!0)}}function Tg(a,b,c){if(b.href){var d=Rg(a,b.href,void 0===c?!1:c);$a.test(d)&&(b.href=d)}}
var Dg=function(a){try{var b;a:{for(var c=a,d=100;c&&0<d;){if(c.href&&c.nodeName.match(/^a(?:rea)?$/i)){b=c;break a}c=c.parentNode;d--}b=null}var e=b;if(e){var g=e.protocol;"http:"!==g&&"https:"!==g||Sg(e,e.hostname,!1)}}catch(h){}},Eg=function(a){try{if(a.action){var b=hb(jb(a.action),"host");Sg(a,b,!0)}}catch(c){}},Ug=function(a,b,c,d){Gg();var e={callback:a,domains:b,fragment:"fragment"===c,forms:!!d};Fg().decorators.push(e)},Vg=function(){var a=C.location.hostname,b=Ig.exec(C.referrer);if(!b)return!1;
var c=b[2],d=b[1],e="";if(c){var g=c.split("/"),h=g[1];e="s"===h?decodeURIComponent(g[2]):decodeURIComponent(h)}else if(d){if(0===d.indexOf("xn--"))return!1;e=d.replace(/-/g,".").replace(/\.\./g,"-")}return a.replace(Jg,"")===e.replace(Jg,"")},Wg=function(a,b){return!1===a?!1:a||b||Vg()};var Xg={};var Yg=/^\w+$/,Zg=/^[\w-]+$/,$g=/^~?[\w-]+$/,ah={aw:"_aw",dc:"_dc",gf:"_gf",ha:"_ha"};function bh(a){return a&&"string"==typeof a&&a.match(Yg)?a:"_gcl"}var dh=function(){var a=jb(u.location.href),b=hb(a,"query",!1,void 0,"gclid"),c=hb(a,"query",!1,void 0,"gclsrc"),d=hb(a,"query",!1,void 0,"dclid");if(!b||!c){var e=a.hash.replace("#","");b=b||eb(e,"gclid",void 0);c=c||eb(e,"gclsrc",void 0)}return ch(b,c,d)};
function ch(a,b,c){var d={},e=function(g,h){d[h]||(d[h]=[]);d[h].push(g)};if(void 0!==a&&a.match(Zg))switch(b){case void 0:e(a,"aw");break;case "aw.ds":e(a,"aw");e(a,"dc");break;case "ds":e(a,"dc");break;case "3p.ds":(void 0==Xg.gtm_3pds?0:Xg.gtm_3pds)&&e(a,"dc");break;case "gf":e(a,"gf");break;case "ha":e(a,"ha")}c&&e(c,"dc");return d}
function eh(a,b,c){function d(p,t){var q=fh(p,e);q&&rb(q,t,h,g,l,!0)}b=b||{};var e=bh(b.prefix),g=b.domain||"auto",h=b.path||"/",k=void 0==b.Zd?7776E3:b.Zd;c=c||wa();var l=0==k?void 0:new Date(c+1E3*k),m=Math.round(c/1E3),n=function(p){return["GCL",m,p].join(".")};a.aw&&(!0===b.Ah?d("aw",n("~"+a.aw[0])):d("aw",n(a.aw[0])));a.dc&&d("dc",n(a.dc[0]));a.gf&&d("gf",n(a.gf[0]));a.ha&&d("ha",n(a.ha[0]))}
var fh=function(a,b){var c=ah[a];if(void 0!==c)return b+c},gh=function(a){var b=a.split(".");return 3!==b.length||"GCL"!==b[0]?0:1E3*(Number(b[1])||0)};function hh(a){var b=a.split(".");if(3==b.length&&"GCL"==b[0]&&b[1])return b[2]}
var ih=function(a,b,c,d,e){if(ka(b)){var g=bh(e);Ug(function(){for(var h={},k=0;k<a.length;++k){var l=fh(a[k],g);if(l){var m=kb(l,C.cookie);m.length&&(h[l]=m.sort()[m.length-1])}}return h},b,c,d)}},jh=function(a){return a.filter(function(b){return $g.test(b)})},kh=function(a){for(var b=["aw","dc"],c=bh(a&&a.prefix),d={},e=0;e<b.length;e++)ah[b[e]]&&(d[b[e]]=ah[b[e]]);ra(d,function(g,h){var k=kb(c+h,C.cookie);if(k.length){var l=k[0],m=gh(l),n={};n[g]=[hh(l)];eh(n,a,m)}})};var lh=/^\d+\.fls\.doubleclick\.net$/;function mh(a){var b=jb(u.location.href),c=hb(b,"host",!1);if(c&&c.match(lh)){var d=hb(b,"path").split(a+"=");if(1<d.length)return d[1].split(";")[0].split("?")[0]}}
function nh(a,b){if("aw"==a||"dc"==a){var c=mh("gcl"+a);if(c)return c.split(".")}var d=bh(b);if("_gcl"==d){var e;e=dh()[a]||[];if(0<e.length)return e}var g=fh(a,d),h;if(g){var k=[];if(C.cookie){var l=kb(g,C.cookie);if(l&&0!=l.length){for(var m=0;m<l.length;m++){var n=hh(l[m]);n&&-1===la(k,n)&&k.push(n)}h=jh(k)}else h=k}else h=k}else h=[];return h}
var oh=function(){var a=mh("gac");if(a)return decodeURIComponent(a);var b=ug(),c=[];ra(b,function(d,e){for(var g=[],h=0;h<e.length;h++)g.push(e[h].Pf);g=jh(g);g.length&&c.push(d+":"+g.join(","))});return c.join(";")},ph=function(a,b,c,d,e){tg(b,c,d,e);var g=pg[qg(b)],h=dh().dc||[],k=!1;if(g&&0<h.length){var l=Ic.joined_au=Ic.joined_au||{},m=b||"_gcl";if(!l[m])for(var n=0;n<h.length;n++){var p="https://adservice.google.com/ddm/regclk",t=p=p+"?gclid="+h[n]+"&auiddc="+g;Ia.sendBeacon&&Ia.sendBeacon(t)||Pa(t);k=l[m]=
!0}}null==a&&(a=k);if(a&&g){var q=qg(b),r=pg[q];r&&sg(q,r,c,d,e)}};var rh;if(3===Hc.Ab.length)rh="g";else{var sh="G";rh=sh}
var th={"":"n",UA:"u",AW:"a",DC:"d",G:"e",GF:"f",HA:"h",GTM:rh,OPT:"o"},uh=function(a){var b=Hc.i.split("-"),c=b[0].toUpperCase(),d=th[c]||"i",e=a&&"GTM"===c?b[1]:"OPT"===c?b[1]:"",g;if(3===Hc.Ab.length){var h=void 0;g="2"+(h||"w")}else g=
"";return g+d+Hc.Ab+e};var zh=["input","select","textarea"],Ah=["button","hidden","image","reset","submit"],Bh=function(a){var b=a.tagName.toLowerCase();return!ma(zh,function(c){return c===b})||"input"===b&&ma(Ah,function(c){return c===a.type.toLowerCase()})?!1:!0},Ch=function(a){return a.form?a.form.tagName?a.form:C.getElementById(a.form):Ya(a,["form"],100)},Dh=function(a,b,c){if(!a.elements)return 0;for(var d=b.getAttribute(c),e=0,g=1;e<a.elements.length;e++){var h=a.elements[e];if(Bh(h)){if(h.getAttribute(c)===d)return g;
g++}}return 0};var Gh=!!u.MutationObserver,Hh=void 0,Ih=function(a){if(!Hh){var b=function(){var c=C.body;if(c)if(Gh)(new MutationObserver(function(){for(var e=0;e<Hh.length;e++)D(Hh[e])})).observe(c,{childList:!0,subtree:!0});else{var d=!1;Qa(c,"DOMNodeInserted",function(){d||(d=!0,D(function(){d=!1;for(var e=0;e<Hh.length;e++)D(Hh[e])}))})}};Hh=[];C.body?b():D(b)}Hh.push(a)};var ji=u.clearTimeout,ki=u.setTimeout,L=function(a,b,c){if(Ad()){b&&D(b)}else return Ma(a,b,c)},li=function(){return new Date},mi=function(){return u.location.href},ni=function(a){return hb(jb(a),"fragment")},oi=function(a){return gb(jb(a))},pi=null;
var qi=function(a,b){return qd(a,b||2)},ri=function(a,b,c){b&&(a.eventCallback=b,c&&(a.eventTimeout=c));return zf(a)},si=function(a,b){u[a]=b},M=function(a,b,c){b&&(void 0===u[a]||c&&!u[a])&&(u[a]=b);return u[a]},ti=function(a,b,c){return kb(a,b,void 0===c?!0:!!c)},ui=function(a,b,c,d){var e={prefix:a,path:b,domain:c,Zd:d},g=dh();eh(g,e);kh(e)},vi=function(a,b,c,d,e){for(var g=Qg(),h=bh(b),k=0;k<a.length;++k){var l=a[k];if(void 0!==ah[l]){var m=fh(l,h),
n=g[m];if(n){var p=Math.min(gh(n),wa()),t;b:{for(var q=p,r=kb(m,C.cookie),v=0;v<r.length;++v)if(gh(r[v])>q){t=!0;break b}t=!1}t||rb(m,n,c,d,0==e?void 0:new Date(p+1E3*(null==e?7776E3:e)),!0)}}}var w={prefix:b,path:c,domain:d};eh(ch(g.gclid,g.gclsrc),w);},wi=function(a,b,c,d,e){ih(a,b,c,d,e);},xi=function(a,b){if(Ad()){
b&&D(b)}else Oa(a,b)},yi=function(a){return!!ig(a,"init",!1)},zi=function(a){gg(a,"init",!0)},Ai=function(a,b,c){var d=(void 0===c?0:c)?"www.googletagmanager.com/gtag/js":Mc;d+="?id="+encodeURIComponent(a)+"&l=dataLayer";b&&ra(b,function(e,g){g&&(d+="&"+e+"="+encodeURIComponent(g))});L(H("https://","http://",d))},Bi=function(a,b){var c=a[b];return c};var Di=bg.ig;
var Ei=new pa,Fi=function(a,b){function c(h){var k=jb(h),l=hb(k,"protocol"),m=hb(k,"host",!0),n=hb(k,"port"),p=hb(k,"path").toLowerCase().replace(/\/$/,"");if(void 0===l||"http"==l&&"80"==n||"https"==l&&"443"==n)l="web",n="default";return[l,m,n,p]}for(var d=c(String(a)),e=c(String(b)),g=0;g<d.length;g++)if(d[g]!==e[g])return!1;return!0},Gi=function(a){var b=a.arg0,c=a.arg1;if(a.any_of&&ka(c)){for(var d=0;d<c.length;d++)if(Gi({"function":a["function"],arg0:b,arg1:c[d]}))return!0;return!1}switch(a["function"]){case "_cn":return 0<=
String(b).indexOf(String(c));case "_css":var e;a:{if(b){var g=["matches","webkitMatchesSelector","mozMatchesSelector","msMatchesSelector","oMatchesSelector"];try{for(var h=0;h<g.length;h++)if(b[g[h]]){e=b[g[h]](c);break a}}catch(v){}}e=!1}return e;case "_ew":var k,l;k=String(b);l=String(c);var m=k.length-l.length;return 0<=m&&k.indexOf(l,m)==m;case "_eq":return String(b)==String(c);case "_ge":return Number(b)>=Number(c);case "_gt":return Number(b)>Number(c);case "_lc":var n;n=String(b).split(",");
return 0<=la(n,String(c));case "_le":return Number(b)<=Number(c);case "_lt":return Number(b)<Number(c);case "_re":var p;var t=a.ignore_case?"i":void 0;try{var q=String(c)+t,r=Ei.get(q);r||(r=new RegExp(c,t),Ei.set(q,r));p=r.test(b)}catch(v){p=!1}return p;case "_sw":return 0==String(b).indexOf(String(c));case "_um":return Fi(b,c)}return!1};var Ii=function(a,b){var c=function(){};c.prototype=a.prototype;var d=new c;a.apply(d,Array.prototype.slice.call(arguments,1));return d};var Ji={},Ki=encodeURI,W=encodeURIComponent,Li=Pa;var Mi=function(a,b){if(!a)return!1;var c=hb(jb(a),"host");if(!c)return!1;for(var d=0;b&&d<b.length;d++){var e=b[d]&&b[d].toLowerCase();if(e){var g=c.length-e.length;0<g&&"."!=e.charAt(0)&&(g--,e="."+e);if(0<=g&&c.indexOf(e,g)==g)return!0}}return!1};
var Ni=function(a,b,c){for(var d={},e=!1,g=0;a&&g<a.length;g++)a[g]&&a[g].hasOwnProperty(b)&&a[g].hasOwnProperty(c)&&(d[a[g][b]]=a[g][c],e=!0);return e?d:null};Ji.fg=function(){var a=!1;return a};var mj=function(){var a=u.gaGlobal=u.gaGlobal||{};a.hid=a.hid||oa();return a.hid};var Dj=function(a,b,c,d){this.n=a;this.t=b;this.p=c;this.d=d},Ej=function(){this.c=1;this.e=[];this.p2=this.p=null};function Fj(a){var b=Ic,c=b.gss=b.gss||{};return c[a]=c[a]||new Ej}
var Gj=function(a){if(Fj(a).p&&!Fj(a).p2){var b=Fj(a).p;Fj(a).p2=function(c,d,e){b(c,d,e.eventModel)}}return Fj(a).p2},Hj=function(a,b){Fj(a).p2=b;Fj(a).p=function(c,d,e){return b(c,d,new Le(e))}},Ij=function(a){var b=Fj(a),c=Gj(a);if(c){var d=b.e,e=[];b.e=[];var g=function(h){for(var k=0;k<h.length;k++)try{var l=h[k];l.d?(l.d=!1,e.push(l)):c(l.n,l.t,new Le(l.p))}catch(m){}};g(d);g(e)}};var bk=window,ck=document,dk=function(a){var b=bk._gaUserPrefs;if(b&&b.ioo&&b.ioo()||a&&!0===bk["ga-disable-"+a])return!0;try{var c=bk.external;if(c&&c._gaUserPrefs&&"oo"==c._gaUserPrefs)return!0}catch(g){}for(var d=kb("AMP_TOKEN",ck.cookie,!0),e=0;e<d.length;e++)if("$OPT_OUT"==d[e])return!0;return ck.getElementById("__gaOptOutExtension")?!0:!1};var ik=!1;ik=!0;
var kk=function(a,b,c){if(ik)Me().push("event",[c,b],a,void 0);else{jk(a);var d=Math.floor(wa()/1E3);Fj(a).e.push(new Dj(b,d,c,void 0));Ij(a)}},lk=function(a,b,c){if(ik)Me().push("event",[c,b],a,!0);else{jk(a);var d=Math.floor(wa()/1E3);Fj(a).e.push(new Dj(b,d,c,!0))}},jk=function(a){if(1===Fj(a).c&&(Fj(a).c=2,!Ad())){var b=encodeURIComponent(a);Ma(("http:"!=u.location.protocol?"https:":"http:")+("//www.googletagmanager.com/gtag/js?id="+b+"&l=dataLayer&cx=c"))}},nk=function(a,b){},mk=function(a,b){},ok=function(a){return"_"===a.charAt(0)},pk=function(a){ra(a,function(c){ok(c)&&
delete a[c]});var b=a[G.vb]||{};ra(b,function(c){ok(c)&&delete b[c]})};var Y={a:{}};Y.a.ctv=["google"],function(){(function(a){Y.__ctv=a;Y.__ctv.b="ctv";Y.__ctv.g=!0;Y.__ctv.priorityOverride=0})(function(){return"121"})}();

Y.a.jsm=["customScripts"],function(){(function(a){Y.__jsm=a;Y.__jsm.b="jsm";Y.__jsm.g=!0;Y.__jsm.priorityOverride=0})(function(a){if(void 0!==a.vtp_javascript){var b=a.vtp_javascript;try{var c=M("google_tag_manager");return c&&c.e&&c.e(b)}catch(d){}}})}();Y.a.c=["google"],function(){(function(a){Y.__c=a;Y.__c.b="c";Y.__c.g=!0;Y.__c.priorityOverride=0})(function(a){return a.vtp_value})}();

Y.a.e=["google"],function(){(function(a){Y.__e=a;Y.__e.b="e";Y.__e.g=!0;Y.__e.priorityOverride=0})(function(a){return String(zd(a.vtp_gtmEventId,"event"))})}();
Y.a.j=["google"],function(){(function(a){Y.__j=a;Y.__j.b="j";Y.__j.g=!0;Y.__j.priorityOverride=0})(function(a){for(var b=String(a.vtp_name).split("."),c=M(b.shift()),d=0;d<b.length;d++)c=c&&c[b[d]];return c})}();Y.a.k=["google"],function(){(function(a){Y.__k=a;Y.__k.b="k";Y.__k.g=!0;Y.__k.priorityOverride=0})(function(a){return ti(a.vtp_name,qi("gtm.cookie",1),!!a.vtp_decodeCookie)[0]})}();


Y.a.u=["google"],function(){var a=function(b){return{toString:function(){return b}}};(function(b){Y.__u=b;Y.__u.b="u";Y.__u.g=!0;Y.__u.priorityOverride=0})(function(b){var c;c=(c=b.vtp_customUrlSource?b.vtp_customUrlSource:qi("gtm.url",1))||mi();var d=b[a("vtp_component")];if(!d||"URL"==d)return oi(String(c));var e=jb(String(c)),g;if("QUERY"===d)a:{var h=b[a("vtp_multiQueryKeys").toString()],k=b[a("vtp_queryKey").toString()]||"",l=b[a("vtp_ignoreEmptyQueryParam").toString()],m;m=h?ka(k)?k:String(k).replace(/\s+/g,
"").split(","):[String(k)];for(var n=0;n<m.length;n++){var p=hb(e,"QUERY",void 0,void 0,m[n]);if(void 0!=p&&(!l||""!==p)){g=p;break a}}g=void 0}else g=hb(e,d,"HOST"==d?b[a("vtp_stripWww")]:void 0,"PATH"==d?b[a("vtp_defaultPages")]:void 0,void 0);return g})}();
Y.a.v=["google"],function(){(function(a){Y.__v=a;Y.__v.b="v";Y.__v.g=!0;Y.__v.priorityOverride=0})(function(a){var b=a.vtp_name;if(!b||!b.replace)return!1;var c=qi(b.replace(/\\\./g,"."),a.vtp_dataLayerVersion||1);return void 0!==c?c:a.vtp_defaultValue})}();
Y.a.ua=["google"],function(){var a,b={},c=function(d){var e={},g={},h={},k={},l={},m=void 0;if(d.vtp_gaSettings){var n=d.vtp_gaSettings;f(Ni(n.vtp_fieldsToSet,"fieldName","value"),g);f(Ni(n.vtp_contentGroup,"index","group"),h);f(Ni(n.vtp_dimension,"index","dimension"),k);f(Ni(n.vtp_metric,"index","metric"),l);d.vtp_gaSettings=null;n.vtp_fieldsToSet=void 0;n.vtp_contentGroup=void 0;n.vtp_dimension=void 0;n.vtp_metric=void 0;var p=f(n);d=f(d,p)}f(Ni(d.vtp_fieldsToSet,"fieldName","value"),g);f(Ni(d.vtp_contentGroup,
"index","group"),h);f(Ni(d.vtp_dimension,"index","dimension"),k);f(Ni(d.vtp_metric,"index","metric"),l);var t=oe(d.vtp_functionName);if(ha(t)){var q="",r="";d.vtp_setTrackerName&&"string"==typeof d.vtp_trackerName?""!==d.vtp_trackerName&&(r=d.vtp_trackerName,q=r+"."):(r="gtm"+Tc(),q=r+".");var v={name:!0,clientId:!0,sampleRate:!0,siteSpeedSampleRate:!0,alwaysSendReferrer:!0,allowAnchor:!0,allowLinker:!0,cookieName:!0,cookieDomain:!0,cookieExpires:!0,cookiePath:!0,cookieUpdate:!0,legacyCookieDomain:!0,
legacyHistoryImport:!0,storage:!0,useAmpClientId:!0,storeGac:!0},w={allowAnchor:!0,allowLinker:!0,alwaysSendReferrer:!0,anonymizeIp:!0,cookieUpdate:!0,exFatal:!0,forceSSL:!0,javaEnabled:!0,legacyHistoryImport:!0,nonInteraction:!0,useAmpClientId:!0,useBeacon:!0,storeGac:!0,allowAdFeatures:!0},x=function(R){var O=[].slice.call(arguments,0);O[0]=q+O[0];t.apply(window,O)},y=function(R,O){return void 0===O?O:R(O)},z=function(R,O){if(O)for(var na in O)O.hasOwnProperty(na)&&x("set",R+na,O[na])},B=function(){},A=function(R,O,na){var Va=0;if(R)for(var Ba in R)if(R.hasOwnProperty(Ba)&&(na&&v[Ba]||!na&&void 0===v[Ba])){var Wa=w[Ba]?ta(R[Ba]):R[Ba];"anonymizeIp"!=Ba||Wa||(Wa=void 0);O[Ba]=Wa;Va++}return Va},E={name:r};A(g,E,!0);t("create",d.vtp_trackingId||e.trackingId,E);x("set","&gtm",uh(!0));d.vtp_enableRecaptcha&&x("require","recaptcha","recaptcha.js");(function(R,O){void 0!==d[O]&&x("set",R,d[O])})("nonInteraction","vtp_nonInteraction");z("contentGroup",h);z("dimension",k);z("metric",l);var F={};A(g,F,!1)&&x("set",F);var I;
d.vtp_enableLinkId&&x("require","linkid","linkid.js");x("set","hitCallback",function(){var R=g&&g.hitCallback;ha(R)&&R();d.vtp_gtmOnSuccess()});if("TRACK_EVENT"==d.vtp_trackType){d.vtp_enableEcommerce&&(x("require","ec","ec.js"),B());var S={hitType:"event",eventCategory:String(d.vtp_eventCategory||e.category),eventAction:String(d.vtp_eventAction||e.action),eventLabel:y(String,d.vtp_eventLabel||e.label),eventValue:y(sa,d.vtp_eventValue||
e.value)};A(I,S,!1);x("send",S);}else if("TRACK_SOCIAL"==d.vtp_trackType){}else if("TRACK_TRANSACTION"==d.vtp_trackType){}else if("TRACK_TIMING"==
d.vtp_trackType){}else if("DECORATE_LINK"==d.vtp_trackType){}else if("DECORATE_FORM"==d.vtp_trackType){}else if("TRACK_DATA"==d.vtp_trackType){}else{d.vtp_enableEcommerce&&(x("require","ec","ec.js"),B());if(d.vtp_doubleClick||"DISPLAY_FEATURES"==d.vtp_advertisingFeaturesType){var X=
"_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");x("require","displayfeatures",void 0,{cookieName:X})}if("DISPLAY_FEATURES_WITH_REMARKETING_LISTS"==d.vtp_advertisingFeaturesType){var Z="_dc_gtm_"+String(d.vtp_trackingId).replace(/[^A-Za-z0-9-]/g,"");x("require","adfeatures",{cookieName:Z})}I?x("send","pageview",I):x("send","pageview");}if(!a){var ca=d.vtp_useDebugVersion?"u/analytics_debug.js":"analytics.js";d.vtp_useInternalVersion&&!d.vtp_useDebugVersion&&(ca="internal/"+ca);a=!0;var Ca=H("https:","http:","//www.google-analytics.com/"+ca,g&&g.forceSSL);L(Ca,function(){var R=me();R&&R.loaded||d.vtp_gtmOnFailure();},d.vtp_gtmOnFailure)}}else D(d.vtp_gtmOnFailure)};Y.__ua=c;Y.__ua.b="ua";Y.__ua.g=!0;Y.__ua.priorityOverride=0}();



Y.a.cid=["google"],function(){(function(a){Y.__cid=a;Y.__cid.b="cid";Y.__cid.g=!0;Y.__cid.priorityOverride=0})(function(){return Hc.i})}();

Y.a.gas=["google"],function(){(function(a){Y.__gas=a;Y.__gas.b="gas";Y.__gas.g=!0;Y.__gas.priorityOverride=0})(function(a){var b=f(a),c=b;c[fc.ja]=null;c[fc.Pe]=null;var d=b=c;d.vtp_fieldsToSet=d.vtp_fieldsToSet||[];var e=d.vtp_cookieDomain;void 0!==e&&(d.vtp_fieldsToSet.push({fieldName:"cookieDomain",value:e}),delete d.vtp_cookieDomain);return b})}();
Y.a.smm=["google"],function(){(function(a){Y.__smm=a;Y.__smm.b="smm";Y.__smm.g=!0;Y.__smm.priorityOverride=0})(function(a){var b=a.vtp_input,c=Ni(a.vtp_map,"key","value")||{};return c.hasOwnProperty(b)?c[b]:a.vtp_defaultValue})}();





Y.a.html=["customScripts"],function(){function a(d,e,g,h){return function(){try{if(0<e.length){var k=e.shift(),l=a(d,e,g,h);if("SCRIPT"==String(k.nodeName).toUpperCase()&&"text/gtmscript"==k.type){var m=C.createElement("script");m.async=!1;m.type="text/javascript";m.id=k.id;m.text=k.text||k.textContent||k.innerHTML||"";k.charset&&(m.charset=k.charset);var n=k.getAttribute("data-gtmsrc");n&&(m.src=n,La(m,l));d.insertBefore(m,null);n||l()}else if(k.innerHTML&&0<=k.innerHTML.toLowerCase().indexOf("<script")){for(var p=
[];k.firstChild;)p.push(k.removeChild(k.firstChild));d.insertBefore(k,null);a(k,p,l,h)()}else d.insertBefore(k,null),l()}else g()}catch(t){D(h)}}}var c=function(d){if(C.body){var e=
d.vtp_gtmOnFailure,g=Di(d.vtp_html,d.vtp_gtmOnSuccess,e),h=g.Ac,k=g.I;if(d.vtp_useIframe){}else d.vtp_supportDocumentWrite?b(h,k,e):a(C.body,Ua(h),k,e)()}else ki(function(){c(d)},
200)};Y.__html=c;Y.__html.b="html";Y.__html.g=!0;Y.__html.priorityOverride=0}();






var qk={};qk.macro=function(a){if(bg.kc.hasOwnProperty(a))return bg.kc[a]},qk.onHtmlSuccess=bg.Hd(!0),qk.onHtmlFailure=bg.Hd(!1);qk.dataLayer=rd;qk.callback=function(a){Rc.hasOwnProperty(a)&&ha(Rc[a])&&Rc[a]();delete Rc[a]};qk.pf=function(){Ic[Hc.i]=qk;za(Sc,Y.a);Yb=Yb||bg;Zb=Rd};
qk.ag=function(){Xg.gtm_3pds=!0;Ic=u.google_tag_manager=u.google_tag_manager||{};if(Ic[Hc.i]){var a=Ic.zones;a&&a.unregisterChild(Hc.i)}else{for(var b=data.resource||{},c=b.macros||[],d=0;d<c.length;d++)Qb.push(c[d]);for(var e=b.tags||[],g=0;g<e.length;g++)Tb.push(e[g]);for(var h=b.predicates||[],
k=0;k<h.length;k++)Sb.push(h[k]);for(var l=b.rules||[],m=0;m<l.length;m++){for(var n=l[m],p={},t=0;t<n.length;t++)p[n[t][0]]=Array.prototype.slice.call(n[t],1);Rb.push(p)}Vb=Y;Wb=Gi;qk.pf();Ff();Ud=!1;Vd=0;if("interactive"==C.readyState&&!C.createEventObject||"complete"==C.readyState)Xd();else{Qa(C,"DOMContentLoaded",Xd);Qa(C,"readystatechange",Xd);if(C.createEventObject&&C.documentElement.doScroll){var q=!0;try{q=!u.frameElement}catch(x){}q&&Yd()}Qa(u,"load",Xd)}tf=!1;"complete"===C.readyState?vf():
Qa(u,"load",vf);a:{if(!gd)break a;u.setInterval(hd,864E5);}
Oc=(new Date).getTime();}};(0,qk.ag)();

})()
